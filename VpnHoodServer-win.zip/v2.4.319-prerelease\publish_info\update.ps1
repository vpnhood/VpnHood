#!/bin/bash
echo "Updating VpnHood Server for Windows...";
$curDir
$localPublishInfoFile="$curDir/publish.json";

# -------------------
# Check for Update
# -------------------

# load local publish info
localPublishInfo = (Get-Content $versionFile | Out-String | ConvertFrom-Json);
localVersion=localPublishInfo.Version;
localUpdateCode=localPublishInfo.UpdateCode;
localUpdateInfoUrl=localPublishInfo.UpdateInfoUrl;

# Check is latest version available
if [ "$localPublishInfoJson" == "" ]; then
    echo "Could not load the installed package information! Path: $localPublishInfoFile";
    exit 1;
fi

# load online publish info
onlinePublishInfoJson=$( wget -qO- $localUpdateInfoUrl);
onlineVersion=$(json_extract Version "$onlinePublishInfoJson");
onlineUpdateCode=$(json_extract UpdateCode "$onlinePublishInfoJson");
onlineInstallScriptUrl=$(json_extract InstallScriptUrl "$onlinePublishInfoJson");

# Check is latest version available
if [ "$onlinePublishInfoJson" == "" ]; then
    echo "Could not retrieve the latest package information! Url: $localUpdateInfoUrl";
    exit 1;
fi

# Compare the update code
if [ "$localUpdateCode" != "$onlineUpdateCode" ]; then
    echo "The installed version can not be updated. You need to update it manaully!";
    exit 1;
fi

# Compare Version
echo "Installed version: $localVersion";
echo "Latest version: $onlineVersion";
if [ $(version "$localVersion") -ge $(version "$onlineVersion") ]; then
    echo "The installed version is up to date.";
    exit 1;
fi

# Install the new version
echo "Installing the latest version";
bash <( wget -qO- "$onlineInstallScriptUrl");
