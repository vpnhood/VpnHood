"use strict";(self["webpackChunkvpnhood_spa"]=self["webpackChunkvpnhood_spa"]||[]).push([[778],{44589:function(e,t,r){r.d(t,{BH:function(){return f},LL:function(){return b},Sg:function(){return p},UG:function(){return d},ZB:function(){return h},ZR:function(){return g},jU:function(){return _},m9:function(){return O},ne:function(){return k},p$:function(){return c},r3:function(){return w}});var n=r(70655),o=function(e){for(var t=[],r=0,n=0;n<e.length;n++){var o=e.charCodeAt(n);o<128?t[r++]=o:o<2048?(t[r++]=o>>6|192,t[r++]=63&o|128):55296===(64512&o)&&n+1<e.length&&56320===(64512&e.charCodeAt(n+1))?(o=65536+((1023&o)<<10)+(1023&e.charCodeAt(++n)),t[r++]=o>>18|240,t[r++]=o>>12&63|128,t[r++]=o>>6&63|128,t[r++]=63&o|128):(t[r++]=o>>12|224,t[r++]=o>>6&63|128,t[r++]=63&o|128)}return t},i=function(e){var t=[],r=0,n=0;while(r<e.length){var o=e[r++];if(o<128)t[n++]=String.fromCharCode(o);else if(o>191&&o<224){var i=e[r++];t[n++]=String.fromCharCode((31&o)<<6|63&i)}else if(o>239&&o<365){i=e[r++];var a=e[r++],s=e[r++],u=((7&o)<<18|(63&i)<<12|(63&a)<<6|63&s)-65536;t[n++]=String.fromCharCode(55296+(u>>10)),t[n++]=String.fromCharCode(56320+(1023&u))}else{i=e[r++],a=e[r++];t[n++]=String.fromCharCode((15&o)<<12|(63&i)<<6|63&a)}}return t.join("")},a={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:"function"===typeof atob,encodeByteArray:function(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();for(var r=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,n=[],o=0;o<e.length;o+=3){var i=e[o],a=o+1<e.length,s=a?e[o+1]:0,u=o+2<e.length,c=u?e[o+2]:0,h=i>>2,l=(3&i)<<4|s>>4,f=(15&s)<<2|c>>6,p=63&c;u||(p=64,a||(f=64)),n.push(r[h],r[l],r[f],r[p])}return n.join("")},encodeString:function(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(o(e),t)},decodeString:function(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):i(this.decodeStringToByteArray(e,t))},decodeStringToByteArray:function(e,t){this.init_();for(var r=t?this.charToByteMapWebSafe_:this.charToByteMap_,n=[],o=0;o<e.length;){var i=r[e.charAt(o++)],a=o<e.length,s=a?r[e.charAt(o)]:0;++o;var u=o<e.length,c=u?r[e.charAt(o)]:64;++o;var h=o<e.length,l=h?r[e.charAt(o)]:64;if(++o,null==i||null==s||null==c||null==l)throw Error();var f=i<<2|s>>4;if(n.push(f),64!==c){var p=s<<4&240|c>>2;if(n.push(p),64!==l){var d=c<<6&192|l;n.push(d)}}}return n},init_:function(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(var e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}},s=function(e){var t=o(e);return a.encodeByteArray(t,!0)},u=function(e){return s(e).replace(/\./g,"")};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function c(e){return h(void 0,e)}function h(e,t){if(!(t instanceof Object))return t;switch(t.constructor){case Date:var r=t;return new Date(r.getTime());case Object:void 0===e&&(e={});break;case Array:e=[];break;default:return t}for(var n in t)t.hasOwnProperty(n)&&l(n)&&(e[n]=h(e[n],t[n]));return e}function l(e){return"__proto__"!==e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var f=function(){function e(){var e=this;this.reject=function(){},this.resolve=function(){},this.promise=new Promise((function(t,r){e.resolve=t,e.reject=r}))}return e.prototype.wrapCallback=function(e){var t=this;return function(r,n){r?t.reject(r):t.resolve(n),"function"===typeof e&&(t.promise.catch((function(){})),1===e.length?e(r):e(r,n))}},e}();
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function p(e,t){if(e.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');var r={alg:"none",type:"JWT"},o=t||"demo-project",i=e.iat||0,a=e.sub||e.user_id;if(!a)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");var s=(0,n.pi)({iss:"https://securetoken.google.com/"+o,aud:o,iat:i,exp:i+3600,auth_time:i,sub:a,user_id:a,firebase:{sign_in_provider:"custom",identities:{}}},e),c="";return[u(JSON.stringify(r)),u(JSON.stringify(s)),c].join(".")}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function d(){try{return"[object process]"===Object.prototype.toString.call(r.g.process)}catch(e){return!1}}function _(){return"object"===typeof self&&self.self===self}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var v="FirebaseError",g=function(e){function t(r,n,o){var i=e.call(this,n)||this;return i.code=r,i.customData=o,i.name=v,Object.setPrototypeOf(i,t.prototype),Error.captureStackTrace&&Error.captureStackTrace(i,b.prototype.create),i}return(0,n.ZT)(t,e),t}(Error),b=function(){function e(e,t,r){this.service=e,this.serviceName=t,this.errors=r}return e.prototype.create=function(e){for(var t=[],r=1;r<arguments.length;r++)t[r-1]=arguments[r];var n=t[0]||{},o=this.service+"/"+e,i=this.errors[e],a=i?m(i,n):"Error",s=this.serviceName+": "+a+" ("+o+").",u=new g(o,s,n);return u},e}();function m(e,t){return e.replace(y,(function(e,r){var n=t[r];return null!=n?String(n):"<"+r+"?>"}))}var y=/\{\$([^}]+)}/g;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function w(e,t){return Object.prototype.hasOwnProperty.call(e,t)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
(function(){function e(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=64,this.pad_[0]=128;for(var e=1;e<this.blockSize;++e)this.pad_[e]=0;this.reset()}e.prototype.reset=function(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0},e.prototype.compress_=function(e,t){t||(t=0);var r=this.W_;if("string"===typeof e)for(var n=0;n<16;n++)r[n]=e.charCodeAt(t)<<24|e.charCodeAt(t+1)<<16|e.charCodeAt(t+2)<<8|e.charCodeAt(t+3),t+=4;else for(n=0;n<16;n++)r[n]=e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3],t+=4;for(n=16;n<80;n++){var o=r[n-3]^r[n-8]^r[n-14]^r[n-16];r[n]=4294967295&(o<<1|o>>>31)}var i,a,s=this.chain_[0],u=this.chain_[1],c=this.chain_[2],h=this.chain_[3],l=this.chain_[4];for(n=0;n<80;n++){n<40?n<20?(i=h^u&(c^h),a=1518500249):(i=u^c^h,a=1859775393):n<60?(i=u&c|h&(u|c),a=2400959708):(i=u^c^h,a=3395469782);o=(s<<5|s>>>27)+i+l+a+r[n]&4294967295;l=h,h=c,c=4294967295&(u<<30|u>>>2),u=s,s=o}this.chain_[0]=this.chain_[0]+s&4294967295,this.chain_[1]=this.chain_[1]+u&4294967295,this.chain_[2]=this.chain_[2]+c&4294967295,this.chain_[3]=this.chain_[3]+h&4294967295,this.chain_[4]=this.chain_[4]+l&4294967295},e.prototype.update=function(e,t){if(null!=e){void 0===t&&(t=e.length);var r=t-this.blockSize,n=0,o=this.buf_,i=this.inbuf_;while(n<t){if(0===i)while(n<=r)this.compress_(e,n),n+=this.blockSize;if("string"===typeof e){while(n<t)if(o[i]=e.charCodeAt(n),++i,++n,i===this.blockSize){this.compress_(o),i=0;break}}else while(n<t)if(o[i]=e[n],++i,++n,i===this.blockSize){this.compress_(o),i=0;break}}this.inbuf_=i,this.total_+=t}},e.prototype.digest=function(){var e=[],t=8*this.total_;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(var r=this.blockSize-1;r>=56;r--)this.buf_[r]=255&t,t/=256;this.compress_(this.buf_);var n=0;for(r=0;r<5;r++)for(var o=24;o>=0;o-=8)e[n]=this.chain_[r]>>o&255,++n;return e}})();function k(e,t){var r=new R(e,t);return r.subscribe.bind(r)}var R=function(){function e(e,t){var r=this;this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then((function(){e(r)})).catch((function(e){r.error(e)}))}return e.prototype.next=function(e){this.forEachObserver((function(t){t.next(e)}))},e.prototype.error=function(e){this.forEachObserver((function(t){t.error(e)})),this.close(e)},e.prototype.complete=function(){this.forEachObserver((function(e){e.complete()})),this.close()},e.prototype.subscribe=function(e,t,r){var n,o=this;if(void 0===e&&void 0===t&&void 0===r)throw new Error("Missing Observer.");n=T(e,["next","error","complete"])?e:{next:e,error:t,complete:r},void 0===n.next&&(n.next=S),void 0===n.error&&(n.error=S),void 0===n.complete&&(n.complete=S);var i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then((function(){try{o.finalError?n.error(o.finalError):n.complete()}catch(e){}})),this.observers.push(n),i},e.prototype.unsubscribeOne=function(e){void 0!==this.observers&&void 0!==this.observers[e]&&(delete this.observers[e],this.observerCount-=1,0===this.observerCount&&void 0!==this.onNoObservers&&this.onNoObservers(this))},e.prototype.forEachObserver=function(e){if(!this.finalized)for(var t=0;t<this.observers.length;t++)this.sendOne(t,e)},e.prototype.sendOne=function(e,t){var r=this;this.task.then((function(){if(void 0!==r.observers&&void 0!==r.observers[e])try{t(r.observers[e])}catch(n){"undefined"!==typeof console&&console.error&&console.error(n)}}))},e.prototype.close=function(e){var t=this;this.finalized||(this.finalized=!0,void 0!==e&&(this.finalError=e),this.task.then((function(){t.observers=void 0,t.onNoObservers=void 0})))},e}();function T(e,t){if("object"!==typeof e||null===e)return!1;for(var r=0,n=t;r<n.length;r++){var o=n[r];if(o in e&&"function"===typeof e[o])return!0}return!1}function S(){}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function O(e){return e&&e._delegate?e._delegate:e}},50626:function(e,t,r){var n=r(75887),o=r(70655),i=r(44589),a=r(30909),s="firebasestorage.googleapis.com",u="storageBucket",c=12e4,h=6e5,l=function(e){function t(r,n){var o=e.call(this,f(r),"Firebase Storage: "+n+" ("+f(r)+")")||this;return o.customData={serverResponse:null},o._baseMessage=o.message,Object.setPrototypeOf(o,t.prototype),o}return(0,o.ZT)(t,e),t.prototype._codeEquals=function(e){return f(e)===this.code},Object.defineProperty(t.prototype,"serverResponse",{get:function(){return this.customData.serverResponse},set:function(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=this._baseMessage+"\n"+this.customData.serverResponse:this.message=this._baseMessage},enumerable:!1,configurable:!0}),t}(i.ZR);function f(e){return"storage/"+e}function p(){var e="An unknown error occurred, please check the error payload for server response.";return new l("unknown",e)}function d(e){return new l("object-not-found","Object '"+e+"' does not exist.")}function _(e){return new l("quota-exceeded","Quota for bucket '"+e+"' exceeded, please view quota on https://firebase.google.com/pricing/.")}function v(){var e="User is not authenticated, please authenticate using Firebase Authentication and try again.";return new l("unauthenticated",e)}function g(){return new l("unauthorized-app","This app does not have permission to access Firebase Storage on this project.")}function b(e){return new l("unauthorized","User does not have permission to access '"+e+"'.")}function m(){return new l("retry-limit-exceeded","Max retry time for operation exceeded, please try again.")}function y(){return new l("canceled","User canceled the upload/download.")}function w(e){return new l("invalid-url","Invalid URL '"+e+"'.")}function k(e){return new l("invalid-default-bucket","Invalid default bucket '"+e+"'.")}function R(){return new l("no-default-bucket","No default bucket found. Did you set the '"+u+"' property when initializing the app?")}function T(){return new l("cannot-slice-blob","Cannot slice blob for upload. Please retry the upload.")}function S(){return new l("server-file-wrong-size","Server recorded incorrect upload file size, please retry the upload.")}function O(){return new l("no-download-url","The given file does not have any download URLs.")}function C(e){return new l("invalid-argument",e)}function E(){return new l("app-deleted","The Firebase app was deleted.")}function P(e){return new l("invalid-root-operation","The operation '"+e+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}function A(e,t){return new l("invalid-format","String does not match format '"+e+"': "+t)}function x(e){throw new l("internal-error","Internal error: "+e)}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function U(e){return atob(e)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var j={RAW:"raw",BASE64:"base64",BASE64URL:"base64url",DATA_URL:"data_url"},B=function(){function e(e,t){this.data=e,this.contentType=t||null}return e}();function I(e,t){switch(e){case j.RAW:return new B(N(t));case j.BASE64:case j.BASE64URL:return new B(M(e,t));case j.DATA_URL:return new B(q(t),z(t))}throw p()}function N(e){for(var t=[],r=0;r<e.length;r++){var n=e.charCodeAt(r);if(n<=127)t.push(n);else if(n<=2047)t.push(192|n>>6,128|63&n);else if(55296===(64512&n)){var o=r<e.length-1&&56320===(64512&e.charCodeAt(r+1));if(o){var i=n,a=e.charCodeAt(++r);n=65536|(1023&i)<<10|1023&a,t.push(240|n>>18,128|n>>12&63,128|n>>6&63,128|63&n)}else t.push(239,191,189)}else 56320===(64512&n)?t.push(239,191,189):t.push(224|n>>12,128|n>>6&63,128|63&n)}return new Uint8Array(t)}function D(e){var t;try{t=decodeURIComponent(e)}catch(r){throw A(j.DATA_URL,"Malformed data URL.")}return N(t)}function M(e,t){switch(e){case j.BASE64:var r=-1!==t.indexOf("-"),n=-1!==t.indexOf("_");if(r||n){var o=r?"-":"_";throw A(e,"Invalid character '"+o+"' found: is it base64url encoded?")}break;case j.BASE64URL:var i=-1!==t.indexOf("+"),a=-1!==t.indexOf("/");if(i||a){o=i?"+":"/";throw A(e,"Invalid character '"+o+"' found: is it base64 encoded?")}t=t.replace(/-/g,"+").replace(/_/g,"/");break}var s;try{s=U(t)}catch(h){throw A(e,"Invalid character found")}for(var u=new Uint8Array(s.length),c=0;c<s.length;c++)u[c]=s.charCodeAt(c);return u}var L=function(){function e(e){this.base64=!1,this.contentType=null;var t=e.match(/^data:([^,]+)?,/);if(null===t)throw A(j.DATA_URL,"Must be formatted 'data:[<mediatype>][;base64],<data>");var r=t[1]||null;null!=r&&(this.base64=F(r,";base64"),this.contentType=this.base64?r.substring(0,r.length-";base64".length):r),this.rest=e.substring(e.indexOf(",")+1)}return e}();function q(e){var t=new L(e);return t.base64?M(j.BASE64,t.rest):D(t.rest)}function z(e){var t=new L(e);return t.contentType}function F(e,t){var r=e.length>=t.length;return!!r&&e.substring(e.length-t.length)===t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var H,W={STATE_CHANGED:"state_changed"},G={RUNNING:"running",PAUSED:"paused",SUCCESS:"success",CANCELED:"canceled",ERROR:"error"};function V(e){switch(e){case"running":case"pausing":case"canceling":return G.RUNNING;case"paused":return G.PAUSED;case"success":return G.SUCCESS;case"canceled":return G.CANCELED;case"error":return G.ERROR;default:return G.ERROR}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(function(e){e[e["NO_ERROR"]=0]="NO_ERROR",e[e["NETWORK_ERROR"]=1]="NETWORK_ERROR",e[e["ABORT"]=2]="ABORT"})(H||(H={}));
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var X=function(){function e(){var e=this;this.sent_=!1,this.xhr_=new XMLHttpRequest,this.errorCode_=H.NO_ERROR,this.sendPromise_=new Promise((function(t){e.xhr_.addEventListener("abort",(function(){e.errorCode_=H.ABORT,t()})),e.xhr_.addEventListener("error",(function(){e.errorCode_=H.NETWORK_ERROR,t()})),e.xhr_.addEventListener("load",(function(){t()}))}))}return e.prototype.send=function(e,t,r,n){if(this.sent_)throw x("cannot .send() more than once");if(this.sent_=!0,this.xhr_.open(t,e,!0),void 0!==n)for(var o in n)n.hasOwnProperty(o)&&this.xhr_.setRequestHeader(o,n[o].toString());return void 0!==r?this.xhr_.send(r):this.xhr_.send(),this.sendPromise_},e.prototype.getErrorCode=function(){if(!this.sent_)throw x("cannot .getErrorCode() before sending");return this.errorCode_},e.prototype.getStatus=function(){if(!this.sent_)throw x("cannot .getStatus() before sending");try{return this.xhr_.status}catch(e){return-1}},e.prototype.getResponseText=function(){if(!this.sent_)throw x("cannot .getResponseText() before sending");return this.xhr_.responseText},e.prototype.abort=function(){this.xhr_.abort()},e.prototype.getResponseHeader=function(e){return this.xhr_.getResponseHeader(e)},e.prototype.addUploadProgressListener=function(e){null!=this.xhr_.upload&&this.xhr_.upload.addEventListener("progress",e)},e.prototype.removeUploadProgressListener=function(e){null!=this.xhr_.upload&&this.xhr_.upload.removeEventListener("progress",e)},e}();function J(){return new X}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Z=function(){function e(){}return e.prototype.createConnection=function(){return J()},e}(),K=function(){function e(e,t){this.bucket=e,this.path_=t}return Object.defineProperty(e.prototype,"path",{get:function(){return this.path_},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"isRoot",{get:function(){return 0===this.path.length},enumerable:!1,configurable:!0}),e.prototype.fullServerUrl=function(){var e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)},e.prototype.bucketOnlyServerUrl=function(){var e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o"},e.makeFromBucketSpec=function(t,r){var n;try{n=e.makeFromUrl(t,r)}catch(o){return new e(t,"")}if(""===n.path)return n;throw k(t)},e.makeFromUrl=function(t,r){var n=null,o="([A-Za-z0-9.\\-_]+)";function i(e){"/"===e.path.charAt(e.path.length-1)&&(e.path_=e.path_.slice(0,-1))}var a="(/(.*))?$",u=new RegExp("^gs://"+o+a,"i"),c={bucket:1,path:3};function h(e){e.path_=decodeURIComponent(e.path)}for(var l="v[A-Za-z0-9_]+",f=r.replace(/[.]/g,"\\."),p="(/([^?#]*).*)?$",d=new RegExp("^https?://"+f+"/"+l+"/b/"+o+"/o"+p,"i"),_={bucket:1,path:3},v=r===s?"(?:storage.googleapis.com|storage.cloud.google.com)":r,g="([^?#]*)",b=new RegExp("^https?://"+v+"/"+o+"/"+g,"i"),m={bucket:1,path:2},y=[{regex:u,indices:c,postModify:i},{regex:d,indices:_,postModify:h},{regex:b,indices:m,postModify:h}],k=0;k<y.length;k++){var R=y[k],T=R.regex.exec(t);if(T){var S=T[R.indices.bucket],O=T[R.indices.path];O||(O=""),n=new e(S,O),R.postModify(n);break}}if(null==n)throw w(t);return n},e}(),$=function(){function e(e){this.promise_=Promise.reject(e)}return e.prototype.getPromise=function(){return this.promise_},e.prototype.cancel=function(e){},e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(e,t,r){var n=1,i=null,a=!1,s=0;function u(){return 2===s}var c=!1;function h(){for(var e=[],r=0;r<arguments.length;r++)e[r]=arguments[r];c||(c=!0,t.apply(null,e))}function l(t){i=setTimeout((function(){i=null,e(f,u())}),t)}function f(e){for(var t=[],r=1;r<arguments.length;r++)t[r-1]=arguments[r];if(!c)if(e)h.call.apply(h,(0,o.ev)([null,e],t));else{var i,f=u()||a;if(f)h.call.apply(h,(0,o.ev)([null,e],t));else n<64&&(n*=2),1===s?(s=2,i=0):i=1e3*(n+Math.random()),l(i)}}var p=!1;function d(e){p||(p=!0,c||(null!==i?(e||(s=2),clearTimeout(i),l(0)):e||(s=1)))}return l(0),setTimeout((function(){a=!0,d(!0)}),r),d}function Q(e){e(!1)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ee(e){return void 0!==e}function te(e){return"function"===typeof e}function re(e){return"object"===typeof e&&!Array.isArray(e)}function ne(e){return"string"===typeof e||e instanceof String}function oe(e){return ie()&&e instanceof Blob}function ie(){return"undefined"!==typeof Blob}function ae(e,t,r,n){if(n<t)throw C("Invalid value for '"+e+"'. Expected "+t+" or greater.");if(n>r)throw C("Invalid value for '"+e+"'. Expected "+r+" or less.")}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function se(e,t){var r=t.match(/^(\w+):\/\/.+/),n=null===r||void 0===r?void 0:r[1],o=t;return null==n&&(o="https://"+t),o+"/v0"+e}function ue(e){var t=encodeURIComponent,r="?";for(var n in e)if(e.hasOwnProperty(n)){var o=t(n)+"="+t(e[n]);r=r+o+"&"}return r=r.slice(0,-1),r}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ce=function(){function e(e,t,r,n,o,i,a,s,u,c,h){var l=this;this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.url_=e,this.method_=t,this.headers_=r,this.body_=n,this.successCodes_=o.slice(),this.additionalRetryCodes_=i.slice(),this.callback_=a,this.errorCallback_=s,this.progressCallback_=c,this.timeout_=u,this.pool_=h,this.promise_=new Promise((function(e,t){l.resolve_=e,l.reject_=t,l.start_()}))}return e.prototype.start_=function(){var e=this;function t(t,r){if(r)t(!1,new he(!1,null,!0));else{var n=e.pool_.createConnection();e.pendingConnection_=n,null!==e.progressCallback_&&n.addUploadProgressListener(o),n.send(e.url_,e.method_,e.body_,e.headers_).then((function(){null!==e.progressCallback_&&n.removeUploadProgressListener(o),e.pendingConnection_=null;var r=n.getErrorCode()===H.NO_ERROR,i=n.getStatus();if(r&&!e.isRetryStatusCode_(i)){var a=-1!==e.successCodes_.indexOf(i);t(!0,new he(a,n))}else{var s=n.getErrorCode()===H.ABORT;t(!1,new he(!1,null,s))}}))}function o(t){var r=t.loaded,n=t.lengthComputable?t.total:-1;null!==e.progressCallback_&&e.progressCallback_(r,n)}}function r(t,r){var n=e.resolve_,o=e.reject_,i=r.connection;if(r.wasSuccessCode)try{var a=e.callback_(i,i.getResponseText());ee(a)?n(a):n()}catch(u){o(u)}else if(null!==i){var s=p();s.serverResponse=i.getResponseText(),e.errorCallback_?o(e.errorCallback_(i,s)):o(s)}else if(r.canceled){s=e.appDelete_?E():y();o(s)}else{s=m();o(s)}}this.canceled_?r(!1,new he(!1,null,!0)):this.backoffId_=Y(t,r,this.timeout_)},e.prototype.getPromise=function(){return this.promise_},e.prototype.cancel=function(e){this.canceled_=!0,this.appDelete_=e||!1,null!==this.backoffId_&&Q(this.backoffId_),null!==this.pendingConnection_&&this.pendingConnection_.abort()},e.prototype.isRetryStatusCode_=function(e){var t=e>=500&&e<600,r=[408,429],n=-1!==r.indexOf(e),o=-1!==this.additionalRetryCodes_.indexOf(e);return t||n||o},e}(),he=function(){function e(e,t,r){this.wasSuccessCode=e,this.connection=t,this.canceled=!!r}return e}();function le(e,t){null!==t&&t.length>0&&(e["Authorization"]="Firebase "+t)}function fe(e,t){e["X-Firebase-Storage-Version"]="webjs/"+(null!==t&&void 0!==t?t:"AppManager")}function pe(e,t){t&&(e["X-Firebase-GMPID"]=t)}function de(e,t){null!==t&&(e["X-Firebase-AppCheck"]=t)}function _e(e,t,r,n,o,i){var a=ue(e.urlParams),s=e.url+a,u=Object.assign({},e.headers);return pe(u,t),le(u,r),fe(u,i),de(u,n),new ce(s,e.method,u,e.body,e.successCodes,e.additionalRetryCodes,e.handler,e.errorHandler,e.timeout,e.progressCallback,o)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ve(){return"undefined"!==typeof BlobBuilder?BlobBuilder:"undefined"!==typeof WebKitBlobBuilder?WebKitBlobBuilder:void 0}function ge(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];var r=ve();if(void 0!==r){for(var n=new r,o=0;o<e.length;o++)n.append(e[o]);return n.getBlob()}if(ie())return new Blob(e);throw new l("unsupported-environment","This browser doesn't seem to support creating Blobs")}function be(e,t,r){return e.webkitSlice?e.webkitSlice(t,r):e.mozSlice?e.mozSlice(t,r):e.slice?e.slice(t,r):null}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var me=function(){function e(e,t){var r=0,n="";oe(e)?(this.data_=e,r=e.size,n=e.type):e instanceof ArrayBuffer?(t?this.data_=new Uint8Array(e):(this.data_=new Uint8Array(e.byteLength),this.data_.set(new Uint8Array(e))),r=this.data_.length):e instanceof Uint8Array&&(t?this.data_=e:(this.data_=new Uint8Array(e.length),this.data_.set(e)),r=e.length),this.size_=r,this.type_=n}return e.prototype.size=function(){return this.size_},e.prototype.type=function(){return this.type_},e.prototype.slice=function(t,r){if(oe(this.data_)){var n=this.data_,o=be(n,t,r);return null===o?null:new e(o)}var i=new Uint8Array(this.data_.buffer,t,r-t);return new e(i,!0)},e.getBlob=function(){for(var t=[],r=0;r<arguments.length;r++)t[r]=arguments[r];if(ie()){var n=t.map((function(t){return t instanceof e?t.data_:t}));return new e(ge.apply(null,n))}var o=t.map((function(e){return ne(e)?I(j.RAW,e).data:e.data_})),i=0;o.forEach((function(e){i+=e.byteLength}));var a=new Uint8Array(i),s=0;return o.forEach((function(e){for(var t=0;t<e.length;t++)a[s++]=e[t]})),new e(a,!0)},e.prototype.uploadData=function(){return this.data_},e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ye(e){var t;try{t=JSON.parse(e)}catch(r){return null}return re(t)?t:null}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function we(e){if(0===e.length)return null;var t=e.lastIndexOf("/");if(-1===t)return"";var r=e.slice(0,t);return r}function ke(e,t){var r=t.split("/").filter((function(e){return e.length>0})).join("/");return 0===e.length?r:e+"/"+r}function Re(e){var t=e.lastIndexOf("/",e.length-2);return-1===t?e:e.slice(t+1)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Te(e,t){return t}var Se=function(){function e(e,t,r,n){this.server=e,this.local=t||e,this.writable=!!r,this.xform=n||Te}return e}(),Oe=null;function Ce(e){return!ne(e)||e.length<2?e:Re(e)}function Ee(){if(Oe)return Oe;var e=[];function t(e,t){return Ce(t)}e.push(new Se("bucket")),e.push(new Se("generation")),e.push(new Se("metageneration")),e.push(new Se("name","fullPath",!0));var r=new Se("name");function n(e,t){return void 0!==t?Number(t):t}r.xform=t,e.push(r);var o=new Se("size");return o.xform=n,e.push(o),e.push(new Se("timeCreated")),e.push(new Se("updated")),e.push(new Se("md5Hash",null,!0)),e.push(new Se("cacheControl",null,!0)),e.push(new Se("contentDisposition",null,!0)),e.push(new Se("contentEncoding",null,!0)),e.push(new Se("contentLanguage",null,!0)),e.push(new Se("contentType",null,!0)),e.push(new Se("metadata","customMetadata",!0)),Oe=e,Oe}function Pe(e,t){function r(){var r=e["bucket"],n=e["fullPath"],o=new K(r,n);return t._makeStorageReference(o)}Object.defineProperty(e,"ref",{get:r})}function Ae(e,t,r){for(var n={type:"file"},o=r.length,i=0;i<o;i++){var a=r[i];n[a.local]=a.xform(n,t[a.server])}return Pe(n,e),n}function xe(e,t,r){var n=ye(t);if(null===n)return null;var o=n;return Ae(e,o,r)}function Ue(e,t,r){var n=ye(t);if(null===n)return null;if(!ne(n["downloadTokens"]))return null;var o=n["downloadTokens"];if(0===o.length)return null;var i=encodeURIComponent,a=o.split(","),s=a.map((function(t){var n=e["bucket"],o=e["fullPath"],a="/b/"+i(n)+"/o/"+i(o),s=se(a,r),u=ue({alt:"media",token:t});return s+u}));return s[0]}function je(e,t){for(var r={},n=t.length,o=0;o<n;o++){var i=t[o];i.writable&&(r[i.server]=e[i.local])}return JSON.stringify(r)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Be="prefixes",Ie="items";function Ne(e,t,r){var n={prefixes:[],items:[],nextPageToken:r["nextPageToken"]};if(r[Be])for(var o=0,i=r[Be];o<i.length;o++){var a=i[o],s=a.replace(/\/$/,""),u=e._makeStorageReference(new K(t,s));n.prefixes.push(u)}if(r[Ie])for(var c=0,h=r[Ie];c<h.length;c++){var l=h[c];u=e._makeStorageReference(new K(t,l["name"]));n.items.push(u)}return n}function De(e,t,r){var n=ye(r);if(null===n)return null;var o=n;return Ne(e,t,o)}var Me=function(){function e(e,t,r,n){this.url=e,this.method=t,this.handler=r,this.timeout=n,this.urlParams={},this.headers={},this.body=null,this.errorHandler=null,this.progressCallback=null,this.successCodes=[200],this.additionalRetryCodes=[]}return e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Le(e){if(!e)throw p()}function qe(e,t){function r(r,n){var o=xe(e,n,t);return Le(null!==o),o}return r}function ze(e,t){function r(r,n){var o=De(e,t,n);return Le(null!==o),o}return r}function Fe(e,t){function r(r,n){var o=xe(e,n,t);return Le(null!==o),Ue(o,n,e.host)}return r}function He(e){function t(t,r){var n;return n=401===t.getStatus()?t.getResponseText().includes("Firebase App Check token is invalid")?g():v():402===t.getStatus()?_(e.bucket):403===t.getStatus()?b(e.path):r,n.serverResponse=r.serverResponse,n}return t}function We(e){var t=He(e);function r(r,n){var o=t(r,n);return 404===r.getStatus()&&(o=d(e.path)),o.serverResponse=n.serverResponse,o}return r}function Ge(e,t,r){var n=t.fullServerUrl(),o=se(n,e.host),i="GET",a=e.maxOperationRetryTime,s=new Me(o,i,qe(e,r),a);return s.errorHandler=We(t),s}function Ve(e,t,r,n,o){var i={};t.isRoot?i["prefix"]="":i["prefix"]=t.path+"/",r&&r.length>0&&(i["delimiter"]=r),n&&(i["pageToken"]=n),o&&(i["maxResults"]=o);var a=t.bucketOnlyServerUrl(),s=se(a,e.host),u="GET",c=e.maxOperationRetryTime,h=new Me(s,u,ze(e,t.bucket),c);return h.urlParams=i,h.errorHandler=He(t),h}function Xe(e,t,r){var n=t.fullServerUrl(),o=se(n,e.host),i="GET",a=e.maxOperationRetryTime,s=new Me(o,i,Fe(e,r),a);return s.errorHandler=We(t),s}function Je(e,t,r,n){var o=t.fullServerUrl(),i=se(o,e.host),a="PATCH",s=je(r,n),u={"Content-Type":"application/json; charset=utf-8"},c=e.maxOperationRetryTime,h=new Me(i,a,qe(e,n),c);return h.headers=u,h.body=s,h.errorHandler=We(t),h}function Ze(e,t){var r=t.fullServerUrl(),n=se(r,e.host),o="DELETE",i=e.maxOperationRetryTime;function a(e,t){}var s=new Me(n,o,a,i);return s.successCodes=[200,204],s.errorHandler=We(t),s}function Ke(e,t){return e&&e["contentType"]||t&&t.type()||"application/octet-stream"}function $e(e,t,r){var n=Object.assign({},r);return n["fullPath"]=e.path,n["size"]=t.size(),n["contentType"]||(n["contentType"]=Ke(null,t)),n}function Ye(e,t,r,n,o){var i=t.bucketOnlyServerUrl(),a={"X-Goog-Upload-Protocol":"multipart"};function s(){for(var e="",t=0;t<2;t++)e+=Math.random().toString().slice(2);return e}var u=s();a["Content-Type"]="multipart/related; boundary="+u;var c=$e(t,n,o),h=je(c,r),l="--"+u+"\r\nContent-Type: application/json; charset=utf-8\r\n\r\n"+h+"\r\n--"+u+"\r\nContent-Type: "+c["contentType"]+"\r\n\r\n",f="\r\n--"+u+"--",p=me.getBlob(l,n,f);if(null===p)throw T();var d={name:c["fullPath"]},_=se(i,e.host),v="POST",g=e.maxUploadRetryTime,b=new Me(_,v,qe(e,r),g);return b.urlParams=d,b.headers=a,b.body=p.uploadData(),b.errorHandler=He(t),b}var Qe=function(){function e(e,t,r,n){this.current=e,this.total=t,this.finalized=!!r,this.metadata=n||null}return e}();function et(e,t){var r=null;try{r=e.getResponseHeader("X-Goog-Upload-Status")}catch(o){Le(!1)}var n=t||["active"];return Le(!!r&&-1!==n.indexOf(r)),r}function tt(e,t,r,n,o){var i=t.bucketOnlyServerUrl(),a=$e(t,n,o),s={name:a["fullPath"]},u=se(i,e.host),c="POST",h={"X-Goog-Upload-Protocol":"resumable","X-Goog-Upload-Command":"start","X-Goog-Upload-Header-Content-Length":""+n.size(),"X-Goog-Upload-Header-Content-Type":a["contentType"],"Content-Type":"application/json; charset=utf-8"},l=je(a,r),f=e.maxUploadRetryTime;function p(e){var t;et(e);try{t=e.getResponseHeader("X-Goog-Upload-URL")}catch(r){Le(!1)}return Le(ne(t)),t}var d=new Me(u,c,p,f);return d.urlParams=s,d.headers=h,d.body=l,d.errorHandler=He(t),d}function rt(e,t,r,n){var o={"X-Goog-Upload-Command":"query"};function i(e){var t=et(e,["active","final"]),r=null;try{r=e.getResponseHeader("X-Goog-Upload-Size-Received")}catch(i){Le(!1)}r||Le(!1);var o=Number(r);return Le(!isNaN(o)),new Qe(o,n.size(),"final"===t)}var a="POST",s=e.maxUploadRetryTime,u=new Me(r,a,i,s);return u.headers=o,u.errorHandler=He(t),u}var nt=262144;function ot(e,t,r,n,o,i,a,s){var u=new Qe(0,0);if(a?(u.current=a.current,u.total=a.total):(u.current=0,u.total=n.size()),n.size()!==u.total)throw S();var c=u.total-u.current,h=c;o>0&&(h=Math.min(h,o));var l=u.current,f=l+h,p=h===c?"upload, finalize":"upload",d={"X-Goog-Upload-Command":p,"X-Goog-Upload-Offset":""+u.current},_=n.slice(l,f);if(null===_)throw T();function v(e,r){var o,a=et(e,["active","final"]),s=u.current+h,c=n.size();return o="final"===a?qe(t,i)(e,r):null,new Qe(s,c,"final"===a,o)}var g="POST",b=t.maxUploadRetryTime,m=new Me(r,g,v,b);return m.headers=d,m.body=_.uploadData(),m.progressCallback=s||null,m.errorHandler=He(e),m}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var it=function(){function e(e,t,r){var n=te(e)||null!=t||null!=r;if(n)this.next=e,this.error=t,this.complete=r;else{var o=e;this.next=o.next,this.error=o.error,this.complete=o.complete}}return e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function at(e){return function(){for(var t=[],r=0;r<arguments.length;r++)t[r]=arguments[r];Promise.resolve().then((function(){return e.apply(void 0,t)}))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var st=function(){function e(e,t,r){var n=this;void 0===r&&(r=null),this._transferred=0,this._needToFetchStatus=!1,this._needToFetchMetadata=!1,this._observers=[],this._error=void 0,this._uploadUrl=void 0,this._request=void 0,this._chunkMultiplier=1,this._resolve=void 0,this._reject=void 0,this._ref=e,this._blob=t,this._metadata=r,this._mappings=Ee(),this._resumable=this._shouldDoResumable(this._blob),this._state="running",this._errorHandler=function(e){n._request=void 0,n._chunkMultiplier=1,e._codeEquals("canceled")?(n._needToFetchStatus=!0,n.completeTransitions_()):(n._error=e,n._transition("error"))},this._metadataErrorHandler=function(e){n._request=void 0,e._codeEquals("canceled")?n.completeTransitions_():(n._error=e,n._transition("error"))},this._promise=new Promise((function(e,t){n._resolve=e,n._reject=t,n._start()})),this._promise.then(null,(function(){}))}return e.prototype._makeProgressCallback=function(){var e=this,t=this._transferred;return function(r){return e._updateProgress(t+r)}},e.prototype._shouldDoResumable=function(e){return e.size()>262144},e.prototype._start=function(){"running"===this._state&&void 0===this._request&&(this._resumable?void 0===this._uploadUrl?this._createResumable():this._needToFetchStatus?this._fetchStatus():this._needToFetchMetadata?this._fetchMetadata():this._continueUpload():this._oneShotUpload())},e.prototype._resolveToken=function(e){var t=this;Promise.all([this._ref.storage._getAuthToken(),this._ref.storage._getAppCheckToken()]).then((function(r){var n=r[0],o=r[1];switch(t._state){case"running":e(n,o);break;case"canceling":t._transition("canceled");break;case"pausing":t._transition("paused");break}}))},e.prototype._createResumable=function(){var e=this;this._resolveToken((function(t,r){var n=tt(e._ref.storage,e._ref._location,e._mappings,e._blob,e._metadata),o=e._ref.storage._makeRequest(n,t,r);e._request=o,o.getPromise().then((function(t){e._request=void 0,e._uploadUrl=t,e._needToFetchStatus=!1,e.completeTransitions_()}),e._errorHandler)}))},e.prototype._fetchStatus=function(){var e=this,t=this._uploadUrl;this._resolveToken((function(r,n){var o=rt(e._ref.storage,e._ref._location,t,e._blob),i=e._ref.storage._makeRequest(o,r,n);e._request=i,i.getPromise().then((function(t){e._request=void 0,e._updateProgress(t.current),e._needToFetchStatus=!1,t.finalized&&(e._needToFetchMetadata=!0),e.completeTransitions_()}),e._errorHandler)}))},e.prototype._continueUpload=function(){var e=this,t=nt*this._chunkMultiplier,r=new Qe(this._transferred,this._blob.size()),n=this._uploadUrl;this._resolveToken((function(o,i){var a;try{a=ot(e._ref._location,e._ref.storage,n,e._blob,t,e._mappings,r,e._makeProgressCallback())}catch(u){return e._error=u,void e._transition("error")}var s=e._ref.storage._makeRequest(a,o,i);e._request=s,s.getPromise().then((function(t){e._increaseMultiplier(),e._request=void 0,e._updateProgress(t.current),t.finalized?(e._metadata=t.metadata,e._transition("success")):e.completeTransitions_()}),e._errorHandler)}))},e.prototype._increaseMultiplier=function(){var e=nt*this._chunkMultiplier;e<33554432&&(this._chunkMultiplier*=2)},e.prototype._fetchMetadata=function(){var e=this;this._resolveToken((function(t,r){var n=Ge(e._ref.storage,e._ref._location,e._mappings),o=e._ref.storage._makeRequest(n,t,r);e._request=o,o.getPromise().then((function(t){e._request=void 0,e._metadata=t,e._transition("success")}),e._metadataErrorHandler)}))},e.prototype._oneShotUpload=function(){var e=this;this._resolveToken((function(t,r){var n=Ye(e._ref.storage,e._ref._location,e._mappings,e._blob,e._metadata),o=e._ref.storage._makeRequest(n,t,r);e._request=o,o.getPromise().then((function(t){e._request=void 0,e._metadata=t,e._updateProgress(e._blob.size()),e._transition("success")}),e._errorHandler)}))},e.prototype._updateProgress=function(e){var t=this._transferred;this._transferred=e,this._transferred!==t&&this._notifyObservers()},e.prototype._transition=function(e){if(this._state!==e)switch(e){case"canceling":this._state=e,void 0!==this._request&&this._request.cancel();break;case"pausing":this._state=e,void 0!==this._request&&this._request.cancel();break;case"running":var t="paused"===this._state;this._state=e,t&&(this._notifyObservers(),this._start());break;case"paused":this._state=e,this._notifyObservers();break;case"canceled":this._error=y(),this._state=e,this._notifyObservers();break;case"error":this._state=e,this._notifyObservers();break;case"success":this._state=e,this._notifyObservers();break}},e.prototype.completeTransitions_=function(){switch(this._state){case"pausing":this._transition("paused");break;case"canceling":this._transition("canceled");break;case"running":this._start();break}},Object.defineProperty(e.prototype,"snapshot",{get:function(){var e=V(this._state);return{bytesTransferred:this._transferred,totalBytes:this._blob.size(),state:e,metadata:this._metadata,task:this,ref:this._ref}},enumerable:!1,configurable:!0}),e.prototype.on=function(e,t,r,n){var o=this,i=new it(t,r,n);return this._addObserver(i),function(){o._removeObserver(i)}},e.prototype.then=function(e,t){return this._promise.then(e,t)},e.prototype.catch=function(e){return this.then(null,e)},e.prototype._addObserver=function(e){this._observers.push(e),this._notifyObserver(e)},e.prototype._removeObserver=function(e){var t=this._observers.indexOf(e);-1!==t&&this._observers.splice(t,1)},e.prototype._notifyObservers=function(){var e=this;this._finishPromise();var t=this._observers.slice();t.forEach((function(t){e._notifyObserver(t)}))},e.prototype._finishPromise=function(){if(void 0!==this._resolve){var e=!0;switch(V(this._state)){case G.SUCCESS:at(this._resolve.bind(null,this.snapshot))();break;case G.CANCELED:case G.ERROR:var t=this._reject;at(t.bind(null,this._error))();break;default:e=!1;break}e&&(this._resolve=void 0,this._reject=void 0)}},e.prototype._notifyObserver=function(e){var t=V(this._state);switch(t){case G.RUNNING:case G.PAUSED:e.next&&at(e.next.bind(e,this.snapshot))();break;case G.SUCCESS:e.complete&&at(e.complete.bind(e))();break;case G.CANCELED:case G.ERROR:e.error&&at(e.error.bind(e,this._error))();break;default:e.error&&at(e.error.bind(e,this._error))()}},e.prototype.resume=function(){var e="paused"===this._state||"pausing"===this._state;return e&&this._transition("running"),e},e.prototype.pause=function(){var e="running"===this._state;return e&&this._transition("pausing"),e},e.prototype.cancel=function(){var e="running"===this._state||"pausing"===this._state;return e&&this._transition("canceling"),e},e}(),ut=function(){function e(e,t){this._service=e,this._location=t instanceof K?t:K.makeFromUrl(t,e.host)}return e.prototype.toString=function(){return"gs://"+this._location.bucket+"/"+this._location.path},e.prototype._newRef=function(t,r){return new e(t,r)},Object.defineProperty(e.prototype,"root",{get:function(){var e=new K(this._location.bucket,"");return this._newRef(this._service,e)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"bucket",{get:function(){return this._location.bucket},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"fullPath",{get:function(){return this._location.path},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"name",{get:function(){return Re(this._location.path)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"storage",{get:function(){return this._service},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"parent",{get:function(){var t=we(this._location.path);if(null===t)return null;var r=new K(this._location.bucket,t);return new e(this._service,r)},enumerable:!1,configurable:!0}),e.prototype._throwIfRoot=function(e){if(""===this._location.path)throw P(e)},e}();
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ct(e,t,r){return e._throwIfRoot("uploadBytesResumable"),new st(e,new me(t),r)}function ht(e){var t={prefixes:[],items:[]};return lt(e,t).then((function(){return t}))}function lt(e,t,r){return(0,o.mG)(this,void 0,void 0,(function(){var n,i,a,s;return(0,o.Jh)(this,(function(o){switch(o.label){case 0:return n={pageToken:r},[4,ft(e,n)];case 1:return i=o.sent(),(a=t.prefixes).push.apply(a,i.prefixes),(s=t.items).push.apply(s,i.items),null==i.nextPageToken?[3,3]:[4,lt(e,t,i.nextPageToken)];case 2:o.sent(),o.label=3;case 3:return[2]}}))}))}function ft(e,t){return(0,o.mG)(this,void 0,void 0,(function(){var r,n;return(0,o.Jh)(this,(function(o){switch(o.label){case 0:return null!=t&&"number"===typeof t.maxResults&&ae("options.maxResults",1,1e3,t.maxResults),r=t||{},n=Ve(e.storage,e._location,"/",r.pageToken,r.maxResults),[4,e.storage.makeRequestWithTokens(n)];case 1:return[2,o.sent().getPromise()]}}))}))}function pt(e){return(0,o.mG)(this,void 0,void 0,(function(){var t;return(0,o.Jh)(this,(function(r){switch(r.label){case 0:return e._throwIfRoot("getMetadata"),t=Ge(e.storage,e._location,Ee()),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,r.sent().getPromise()]}}))}))}function dt(e,t){return(0,o.mG)(this,void 0,void 0,(function(){var r;return(0,o.Jh)(this,(function(n){switch(n.label){case 0:return e._throwIfRoot("updateMetadata"),r=Je(e.storage,e._location,t,Ee()),[4,e.storage.makeRequestWithTokens(r)];case 1:return[2,n.sent().getPromise()]}}))}))}function _t(e){return(0,o.mG)(this,void 0,void 0,(function(){var t;return(0,o.Jh)(this,(function(r){switch(r.label){case 0:return e._throwIfRoot("getDownloadURL"),t=Xe(e.storage,e._location,Ee()),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,r.sent().getPromise().then((function(e){if(null===e)throw O();return e}))]}}))}))}function vt(e){return(0,o.mG)(this,void 0,void 0,(function(){var t;return(0,o.Jh)(this,(function(r){switch(r.label){case 0:return e._throwIfRoot("deleteObject"),t=Ze(e.storage,e._location),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,r.sent().getPromise()]}}))}))}function gt(e,t){var r=ke(e._location.path,t),n=new K(e._location.bucket,r);return new ut(e.storage,n)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bt(e){return/^[A-Za-z]+:\/\//.test(e)}function mt(e,t){return new ut(e,t)}function yt(e,t){if(e instanceof Tt){var r=e;if(null==r._bucket)throw R();var n=new ut(r,r._bucket);return null!=t?yt(n,t):n}return void 0!==t?gt(e,t):e}function wt(e,t){if(t&&bt(t)){if(e instanceof Tt)return mt(e,t);throw C("To use ref(service, url), the first argument must be a Storage instance.")}return yt(e,t)}function kt(e,t){var r=null===t||void 0===t?void 0:t[u];return null==r?null:K.makeFromBucketSpec(r,e)}function Rt(e,t,r,n){void 0===n&&(n={}),e.host="http://"+t+":"+r;var o=n.mockUserToken;o&&(e._overrideAuthToken="string"===typeof o?o:(0,i.Sg)(o,e.app.options.projectId))}var Tt=function(){function e(e,t,r,n,o,i){this.app=e,this._authProvider=t,this._appCheckProvider=r,this._pool=n,this._url=o,this._firebaseVersion=i,this._bucket=null,this._host=s,this._appId=null,this._deleted=!1,this._maxOperationRetryTime=c,this._maxUploadRetryTime=h,this._requests=new Set,this._bucket=null!=o?K.makeFromBucketSpec(o,this._host):kt(this._host,this.app.options)}return Object.defineProperty(e.prototype,"host",{get:function(){return this._host},set:function(e){this._host=e,null!=this._url?this._bucket=K.makeFromBucketSpec(this._url,e):this._bucket=kt(e,this.app.options)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxUploadRetryTime",{get:function(){return this._maxUploadRetryTime},set:function(e){ae("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxOperationRetryTime",{get:function(){return this._maxOperationRetryTime},set:function(e){ae("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e},enumerable:!1,configurable:!0}),e.prototype._getAuthToken=function(){return(0,o.mG)(this,void 0,void 0,(function(){var e,t;return(0,o.Jh)(this,(function(r){switch(r.label){case 0:return this._overrideAuthToken?[2,this._overrideAuthToken]:(e=this._authProvider.getImmediate({optional:!0}),e?[4,e.getToken()]:[3,2]);case 1:if(t=r.sent(),null!==t)return[2,t.accessToken];r.label=2;case 2:return[2,null]}}))}))},e.prototype._getAppCheckToken=function(){return(0,o.mG)(this,void 0,void 0,(function(){var e,t;return(0,o.Jh)(this,(function(r){switch(r.label){case 0:return e=this._appCheckProvider.getImmediate({optional:!0}),e?[4,e.getToken()]:[3,2];case 1:return t=r.sent(),[2,t.token];case 2:return[2,null]}}))}))},e.prototype._delete=function(){return this._deleted||(this._deleted=!0,this._requests.forEach((function(e){return e.cancel()})),this._requests.clear()),Promise.resolve()},e.prototype._makeStorageReference=function(e){return new ut(this,e)},e.prototype._makeRequest=function(e,t,r){var n=this;if(this._deleted)return new $(E());var o=_e(e,this._appId,t,r,this._pool,this._firebaseVersion);return this._requests.add(o),o.getPromise().then((function(){return n._requests.delete(o)}),(function(){return n._requests.delete(o)})),o},e.prototype.makeRequestWithTokens=function(e){return(0,o.mG)(this,void 0,void 0,(function(){var t,r,n;return(0,o.Jh)(this,(function(o){switch(o.label){case 0:return[4,Promise.all([this._getAuthToken(),this._getAppCheckToken()])];case 1:return t=o.sent(),r=t[0],n=t[1],[2,this._makeRequest(e,r,n)]}}))}))},e}();
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function St(e,t,r){return e=(0,i.m9)(e),ct(e,t,r)}function Ot(e){return e=(0,i.m9)(e),pt(e)}function Ct(e,t){return e=(0,i.m9)(e),dt(e,t)}function Et(e,t){return e=(0,i.m9)(e),ft(e,t)}function Pt(e){return e=(0,i.m9)(e),ht(e)}function At(e){return e=(0,i.m9)(e),_t(e)}function xt(e){return e=(0,i.m9)(e),vt(e)}function Ut(e,t){return e=(0,i.m9)(e),wt(e,t)}function jt(e,t){return gt(e,t)}function Bt(e,t,r,n){void 0===n&&(n={}),Rt(e,t,r,n)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var It=function(){function e(e,t,r){this._delegate=e,this.task=t,this.ref=r}return Object.defineProperty(e.prototype,"bytesTransferred",{get:function(){return this._delegate.bytesTransferred},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"metadata",{get:function(){return this._delegate.metadata},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"state",{get:function(){return this._delegate.state},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"totalBytes",{get:function(){return this._delegate.totalBytes},enumerable:!1,configurable:!0}),e}(),Nt=function(){function e(e,t){this._delegate=e,this._ref=t,this.cancel=this._delegate.cancel.bind(this._delegate),this.catch=this._delegate.catch.bind(this._delegate),this.pause=this._delegate.pause.bind(this._delegate),this.resume=this._delegate.resume.bind(this._delegate)}return Object.defineProperty(e.prototype,"snapshot",{get:function(){return new It(this._delegate.snapshot,this,this._ref)},enumerable:!1,configurable:!0}),e.prototype.then=function(e,t){var r=this;return this._delegate.then((function(t){if(e)return e(new It(t,r,r._ref))}),t)},e.prototype.on=function(e,t,r,n){var o=this,i=void 0;return t&&(i="function"===typeof t?function(e){return t(new It(e,o,o._ref))}:{next:t.next?function(e){return t.next(new It(e,o,o._ref))}:void 0,complete:t.complete||void 0,error:t.error||void 0}),this._delegate.on(e,i,r||void 0,n||void 0)},e}(),Dt=function(){function e(e,t){this._delegate=e,this._service=t}return Object.defineProperty(e.prototype,"prefixes",{get:function(){var e=this;return this._delegate.prefixes.map((function(t){return new Mt(t,e._service)}))},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"items",{get:function(){var e=this;return this._delegate.items.map((function(t){return new Mt(t,e._service)}))},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"nextPageToken",{get:function(){return this._delegate.nextPageToken||null},enumerable:!1,configurable:!0}),e}(),Mt=function(){function e(e,t){this._delegate=e,this.storage=t}return Object.defineProperty(e.prototype,"name",{get:function(){return this._delegate.name},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"bucket",{get:function(){return this._delegate.bucket},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"fullPath",{get:function(){return this._delegate.fullPath},enumerable:!1,configurable:!0}),e.prototype.toString=function(){return this._delegate.toString()},e.prototype.child=function(t){var r=jt(this._delegate,t);return new e(r,this.storage)},Object.defineProperty(e.prototype,"root",{get:function(){return new e(this._delegate.root,this.storage)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"parent",{get:function(){var t=this._delegate.parent;return null==t?null:new e(t,this.storage)},enumerable:!1,configurable:!0}),e.prototype.put=function(e,t){return this._throwIfRoot("put"),new Nt(St(this._delegate,e,t),this)},e.prototype.putString=function(e,t,r){void 0===t&&(t=j.RAW),this._throwIfRoot("putString");var n=I(t,e),i=(0,o.pi)({},r);return null==i["contentType"]&&null!=n.contentType&&(i["contentType"]=n.contentType),new Nt(new st(this._delegate,new me(n.data,!0),i),this)},e.prototype.listAll=function(){var e=this;return Pt(this._delegate).then((function(t){return new Dt(t,e.storage)}))},e.prototype.list=function(e){var t=this;return Et(this._delegate,e||void 0).then((function(e){return new Dt(e,t.storage)}))},e.prototype.getMetadata=function(){return Ot(this._delegate)},e.prototype.updateMetadata=function(e){return Ct(this._delegate,e)},e.prototype.getDownloadURL=function(){return At(this._delegate)},e.prototype.delete=function(){return this._throwIfRoot("delete"),xt(this._delegate)},e.prototype._throwIfRoot=function(e){if(""===this._delegate._location.path)throw P(e)},e}(),Lt=function(){function e(e,t){this.app=e,this._delegate=t}return Object.defineProperty(e.prototype,"maxOperationRetryTime",{get:function(){return this._delegate.maxOperationRetryTime},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxUploadRetryTime",{get:function(){return this._delegate.maxUploadRetryTime},enumerable:!1,configurable:!0}),e.prototype.ref=function(e){if(bt(e))throw C("ref() expected a child path but got a URL, use refFromURL instead.");return new Mt(Ut(this._delegate,e),this)},e.prototype.refFromURL=function(e){if(!bt(e))throw C("refFromURL() expected a full URL but got a child path, use ref() instead.");try{K.makeFromUrl(e,this._delegate.host)}catch(t){throw C("refFromUrl() expected a valid full URL but got an invalid one.")}return new Mt(Ut(this._delegate,e),this)},e.prototype.setMaxUploadRetryTime=function(e){this._delegate.maxUploadRetryTime=e},e.prototype.setMaxOperationRetryTime=function(e){this._delegate.maxOperationRetryTime=e},e.prototype.useEmulator=function(e,t,r){void 0===r&&(r={}),Bt(this._delegate,e,t,r)},e}(),qt="@firebase/storage",zt="0.7.1",Ft="storage";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ht(e,t){var r=t.instanceIdentifier,o=e.getProvider("app").getImmediate(),i=e.getProvider("auth-internal"),a=e.getProvider("app-check-internal"),s=new Lt(o,new Tt(o,i,a,new Z,r,n.Z.SDK_VERSION));return s}function Wt(e){var t={TaskState:G,TaskEvent:W,StringFormat:j,Storage:Tt,Reference:Mt};e.INTERNAL.registerComponent(new a.wA(Ft,Ht,"PUBLIC").setServiceProps(t).setMultipleInstances(!0)),e.registerVersion(qt,zt)}Wt(n.Z)}}]);