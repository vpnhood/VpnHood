﻿namespace VpnHood.AccessServer.HostProviders.Ovh.Dto;

public class RoutedTo
{
    public required string ServiceName { get; set; }
}