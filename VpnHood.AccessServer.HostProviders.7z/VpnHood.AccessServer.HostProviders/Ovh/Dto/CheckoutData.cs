﻿namespace VpnHood.AccessServer.HostProviders.Ovh.Dto;

internal class CheckoutData
{
    public int? OrderId { get; set; }
    public string? Url { get; set; }
}