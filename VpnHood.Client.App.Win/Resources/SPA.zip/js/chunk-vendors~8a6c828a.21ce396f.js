(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-vendors~8a6c828a"],{"2e66":function(e,t,n){"use strict";var r=n("cc84"),o=n("9ab4"),i=n("a8e9"),s=n("ffa6"),a="firebasestorage.googleapis.com",u="storageBucket",c=12e4,l=6e5,h=function(e){function t(n,r){var o=e.call(this,f(n),"Firebase Storage: "+r+" ("+f(n)+")")||this;return o.customData={serverResponse:null},o._baseMessage=o.message,Object.setPrototypeOf(o,t.prototype),o}return Object(o["c"])(t,e),t.prototype._codeEquals=function(e){return f(e)===this.code},Object.defineProperty(t.prototype,"serverResponse",{get:function(){return this.customData.serverResponse},set:function(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=this._baseMessage+"\n"+this.customData.serverResponse:this.message=this._baseMessage},enumerable:!1,configurable:!0}),t}(i["c"]);function f(e){return"storage/"+e}function p(){var e="An unknown error occurred, please check the error payload for server response.";return new h("unknown",e)}function d(e){return new h("object-not-found","Object '"+e+"' does not exist.")}function v(e){return new h("quota-exceeded","Quota for bucket '"+e+"' exceeded, please view quota on https://firebase.google.com/pricing/.")}function _(){var e="User is not authenticated, please authenticate using Firebase Authentication and try again.";return new h("unauthenticated",e)}function g(){return new h("unauthorized-app","This app does not have permission to access Firebase Storage on this project.")}function b(e){return new h("unauthorized","User does not have permission to access '"+e+"'.")}function m(){return new h("retry-limit-exceeded","Max retry time for operation exceeded, please try again.")}function y(){return new h("canceled","User canceled the upload/download.")}function w(e){return new h("invalid-url","Invalid URL '"+e+"'.")}function R(e){return new h("invalid-default-bucket","Invalid default bucket '"+e+"'.")}function O(){return new h("no-default-bucket","No default bucket found. Did you set the '"+u+"' property when initializing the app?")}function k(){return new h("cannot-slice-blob","Cannot slice blob for upload. Please retry the upload.")}function T(){return new h("server-file-wrong-size","Server recorded incorrect upload file size, please retry the upload.")}function C(){return new h("no-download-url","The given file does not have any download URLs.")}function S(e){return new h("invalid-argument",e)}function E(){return new h("app-deleted","The Firebase app was deleted.")}function P(e){return new h("invalid-root-operation","The operation '"+e+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}function I(e,t){return new h("invalid-format","String does not match format '"+e+"': "+t)}function x(e){throw new h("internal-error","Internal error: "+e)}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function j(e){return atob(e)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var U={RAW:"raw",BASE64:"base64",BASE64URL:"base64url",DATA_URL:"data_url"},A=function(){function e(e,t){this.data=e,this.contentType=t||null}return e}();function L(e,t){switch(e){case U.RAW:return new A(z(t));case U.BASE64:case U.BASE64URL:return new A(H(e,t));case U.DATA_URL:return new A(B(t),M(t))}throw p()}function z(e){for(var t=[],n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<=127)t.push(r);else if(r<=2047)t.push(192|r>>6,128|63&r);else if(55296===(64512&r)){var o=n<e.length-1&&56320===(64512&e.charCodeAt(n+1));if(o){var i=r,s=e.charCodeAt(++n);r=65536|(1023&i)<<10|1023&s,t.push(240|r>>18,128|r>>12&63,128|r>>6&63,128|63&r)}else t.push(239,191,189)}else 56320===(64512&r)?t.push(239,191,189):t.push(224|r>>12,128|r>>6&63,128|63&r)}return new Uint8Array(t)}function N(e){var t;try{t=decodeURIComponent(e)}catch(n){throw I(U.DATA_URL,"Malformed data URL.")}return z(t)}function H(e,t){switch(e){case U.BASE64:var n=-1!==t.indexOf("-"),r=-1!==t.indexOf("_");if(n||r){var o=n?"-":"_";throw I(e,"Invalid character '"+o+"' found: is it base64url encoded?")}break;case U.BASE64URL:var i=-1!==t.indexOf("+"),s=-1!==t.indexOf("/");if(i||s){o=i?"+":"/";throw I(e,"Invalid character '"+o+"' found: is it base64 encoded?")}t=t.replace(/-/g,"+").replace(/_/g,"/");break}var a;try{a=j(t)}catch(l){throw I(e,"Invalid character found")}for(var u=new Uint8Array(a.length),c=0;c<a.length;c++)u[c]=a.charCodeAt(c);return u}var D=function(){function e(e){this.base64=!1,this.contentType=null;var t=e.match(/^data:([^,]+)?,/);if(null===t)throw I(U.DATA_URL,"Must be formatted 'data:[<mediatype>][;base64],<data>");var n=t[1]||null;null!=n&&(this.base64=q(n,";base64"),this.contentType=this.base64?n.substring(0,n.length-";base64".length):n),this.rest=e.substring(e.indexOf(",")+1)}return e}();function B(e){var t=new D(e);return t.base64?H(U.BASE64,t.rest):N(t.rest)}function M(e){var t=new D(e);return t.contentType}function q(e,t){var n=e.length>=t.length;return!!n&&e.substring(e.length-t.length)===t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var F,G={STATE_CHANGED:"state_changed"},W={RUNNING:"running",PAUSED:"paused",SUCCESS:"success",CANCELED:"canceled",ERROR:"error"};function X(e){switch(e){case"running":case"pausing":case"canceling":return W.RUNNING;case"paused":return W.PAUSED;case"success":return W.SUCCESS;case"canceled":return W.CANCELED;case"error":return W.ERROR;default:return W.ERROR}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(function(e){e[e["NO_ERROR"]=0]="NO_ERROR",e[e["NETWORK_ERROR"]=1]="NETWORK_ERROR",e[e["ABORT"]=2]="ABORT"})(F||(F={}));
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var V=function(){function e(){var e=this;this.sent_=!1,this.xhr_=new XMLHttpRequest,this.errorCode_=F.NO_ERROR,this.sendPromise_=new Promise((function(t){e.xhr_.addEventListener("abort",(function(){e.errorCode_=F.ABORT,t()})),e.xhr_.addEventListener("error",(function(){e.errorCode_=F.NETWORK_ERROR,t()})),e.xhr_.addEventListener("load",(function(){t()}))}))}return e.prototype.send=function(e,t,n,r){if(this.sent_)throw x("cannot .send() more than once");if(this.sent_=!0,this.xhr_.open(t,e,!0),void 0!==r)for(var o in r)r.hasOwnProperty(o)&&this.xhr_.setRequestHeader(o,r[o].toString());return void 0!==n?this.xhr_.send(n):this.xhr_.send(),this.sendPromise_},e.prototype.getErrorCode=function(){if(!this.sent_)throw x("cannot .getErrorCode() before sending");return this.errorCode_},e.prototype.getStatus=function(){if(!this.sent_)throw x("cannot .getStatus() before sending");try{return this.xhr_.status}catch(e){return-1}},e.prototype.getResponseText=function(){if(!this.sent_)throw x("cannot .getResponseText() before sending");return this.xhr_.responseText},e.prototype.abort=function(){this.xhr_.abort()},e.prototype.getResponseHeader=function(e){return this.xhr_.getResponseHeader(e)},e.prototype.addUploadProgressListener=function(e){null!=this.xhr_.upload&&this.xhr_.upload.addEventListener("progress",e)},e.prototype.removeUploadProgressListener=function(e){null!=this.xhr_.upload&&this.xhr_.upload.removeEventListener("progress",e)},e}();function K(){return new V}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var J=function(){function e(){}return e.prototype.createConnection=function(){return K()},e}(),Z=function(){function e(e,t){this.bucket=e,this.path_=t}return Object.defineProperty(e.prototype,"path",{get:function(){return this.path_},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"isRoot",{get:function(){return 0===this.path.length},enumerable:!1,configurable:!0}),e.prototype.fullServerUrl=function(){var e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)},e.prototype.bucketOnlyServerUrl=function(){var e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o"},e.makeFromBucketSpec=function(t,n){var r;try{r=e.makeFromUrl(t,n)}catch(o){return new e(t,"")}if(""===r.path)return r;throw R(t)},e.makeFromUrl=function(t,n){var r=null,o="([A-Za-z0-9.\\-_]+)";function i(e){"/"===e.path.charAt(e.path.length-1)&&(e.path_=e.path_.slice(0,-1))}var s="(/(.*))?$",u=new RegExp("^gs://"+o+s,"i"),c={bucket:1,path:3};function l(e){e.path_=decodeURIComponent(e.path)}for(var h="v[A-Za-z0-9_]+",f=n.replace(/[.]/g,"\\."),p="(/([^?#]*).*)?$",d=new RegExp("^https?://"+f+"/"+h+"/b/"+o+"/o"+p,"i"),v={bucket:1,path:3},_=n===a?"(?:storage.googleapis.com|storage.cloud.google.com)":n,g="([^?#]*)",b=new RegExp("^https?://"+_+"/"+o+"/"+g,"i"),m={bucket:1,path:2},y=[{regex:u,indices:c,postModify:i},{regex:d,indices:v,postModify:l},{regex:b,indices:m,postModify:l}],R=0;R<y.length;R++){var O=y[R],k=O.regex.exec(t);if(k){var T=k[O.indices.bucket],C=k[O.indices.path];C||(C=""),r=new e(T,C),O.postModify(r);break}}if(null==r)throw w(t);return r},e}(),$=function(){function e(e){this.promise_=Promise.reject(e)}return e.prototype.getPromise=function(){return this.promise_},e.prototype.cancel=function(e){},e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(e,t,n){var r=1,i=null,s=!1,a=0;function u(){return 2===a}var c=!1;function l(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n];c||(c=!0,t.apply(null,e))}function h(t){i=setTimeout((function(){i=null,e(f,u())}),t)}function f(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];if(!c)if(e)l.call.apply(l,Object(o["f"])([null,e],t));else{var i,f=u()||s;if(f)l.call.apply(l,Object(o["f"])([null,e],t));else r<64&&(r*=2),1===a?(a=2,i=0):i=1e3*(r+Math.random()),h(i)}}var p=!1;function d(e){p||(p=!0,c||(null!==i?(e||(a=2),clearTimeout(i),h(0)):e||(a=1)))}return h(0),setTimeout((function(){s=!0,d(!0)}),n),d}function Q(e){e(!1)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ee(e){return void 0!==e}function te(e){return"function"===typeof e}function ne(e){return"object"===typeof e&&!Array.isArray(e)}function re(e){return"string"===typeof e||e instanceof String}function oe(e){return ie()&&e instanceof Blob}function ie(){return"undefined"!==typeof Blob}function se(e,t,n,r){if(r<t)throw S("Invalid value for '"+e+"'. Expected "+t+" or greater.");if(r>n)throw S("Invalid value for '"+e+"'. Expected "+n+" or less.")}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ae(e,t){var n=t.match(/^(\w+):\/\/.+/),r=null===n||void 0===n?void 0:n[1],o=t;return null==r&&(o="https://"+t),o+"/v0"+e}function ue(e){var t=encodeURIComponent,n="?";for(var r in e)if(e.hasOwnProperty(r)){var o=t(r)+"="+t(e[r]);n=n+o+"&"}return n=n.slice(0,-1),n}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ce=function(){function e(e,t,n,r,o,i,s,a,u,c,l){var h=this;this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.url_=e,this.method_=t,this.headers_=n,this.body_=r,this.successCodes_=o.slice(),this.additionalRetryCodes_=i.slice(),this.callback_=s,this.errorCallback_=a,this.progressCallback_=c,this.timeout_=u,this.pool_=l,this.promise_=new Promise((function(e,t){h.resolve_=e,h.reject_=t,h.start_()}))}return e.prototype.start_=function(){var e=this;function t(t,n){if(n)t(!1,new le(!1,null,!0));else{var r=e.pool_.createConnection();e.pendingConnection_=r,null!==e.progressCallback_&&r.addUploadProgressListener(o),r.send(e.url_,e.method_,e.body_,e.headers_).then((function(){null!==e.progressCallback_&&r.removeUploadProgressListener(o),e.pendingConnection_=null;var n=r.getErrorCode()===F.NO_ERROR,i=r.getStatus();if(n&&!e.isRetryStatusCode_(i)){var s=-1!==e.successCodes_.indexOf(i);t(!0,new le(s,r))}else{var a=r.getErrorCode()===F.ABORT;t(!1,new le(!1,null,a))}}))}function o(t){var n=t.loaded,r=t.lengthComputable?t.total:-1;null!==e.progressCallback_&&e.progressCallback_(n,r)}}function n(t,n){var r=e.resolve_,o=e.reject_,i=n.connection;if(n.wasSuccessCode)try{var s=e.callback_(i,i.getResponseText());ee(s)?r(s):r()}catch(u){o(u)}else if(null!==i){var a=p();a.serverResponse=i.getResponseText(),e.errorCallback_?o(e.errorCallback_(i,a)):o(a)}else if(n.canceled){a=e.appDelete_?E():y();o(a)}else{a=m();o(a)}}this.canceled_?n(!1,new le(!1,null,!0)):this.backoffId_=Y(t,n,this.timeout_)},e.prototype.getPromise=function(){return this.promise_},e.prototype.cancel=function(e){this.canceled_=!0,this.appDelete_=e||!1,null!==this.backoffId_&&Q(this.backoffId_),null!==this.pendingConnection_&&this.pendingConnection_.abort()},e.prototype.isRetryStatusCode_=function(e){var t=e>=500&&e<600,n=[408,429],r=-1!==n.indexOf(e),o=-1!==this.additionalRetryCodes_.indexOf(e);return t||r||o},e}(),le=function(){function e(e,t,n){this.wasSuccessCode=e,this.connection=t,this.canceled=!!n}return e}();function he(e,t){null!==t&&t.length>0&&(e["Authorization"]="Firebase "+t)}function fe(e,t){e["X-Firebase-Storage-Version"]="webjs/"+(null!==t&&void 0!==t?t:"AppManager")}function pe(e,t){t&&(e["X-Firebase-GMPID"]=t)}function de(e,t){null!==t&&(e["X-Firebase-AppCheck"]=t)}function ve(e,t,n,r,o,i){var s=ue(e.urlParams),a=e.url+s,u=Object.assign({},e.headers);return pe(u,t),he(u,n),fe(u,i),de(u,r),new ce(a,e.method,u,e.body,e.successCodes,e.additionalRetryCodes,e.handler,e.errorHandler,e.timeout,e.progressCallback,o)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _e(){return"undefined"!==typeof BlobBuilder?BlobBuilder:"undefined"!==typeof WebKitBlobBuilder?WebKitBlobBuilder:void 0}function ge(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];var n=_e();if(void 0!==n){for(var r=new n,o=0;o<e.length;o++)r.append(e[o]);return r.getBlob()}if(ie())return new Blob(e);throw new h("unsupported-environment","This browser doesn't seem to support creating Blobs")}function be(e,t,n){return e.webkitSlice?e.webkitSlice(t,n):e.mozSlice?e.mozSlice(t,n):e.slice?e.slice(t,n):null}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var me=function(){function e(e,t){var n=0,r="";oe(e)?(this.data_=e,n=e.size,r=e.type):e instanceof ArrayBuffer?(t?this.data_=new Uint8Array(e):(this.data_=new Uint8Array(e.byteLength),this.data_.set(new Uint8Array(e))),n=this.data_.length):e instanceof Uint8Array&&(t?this.data_=e:(this.data_=new Uint8Array(e.length),this.data_.set(e)),n=e.length),this.size_=n,this.type_=r}return e.prototype.size=function(){return this.size_},e.prototype.type=function(){return this.type_},e.prototype.slice=function(t,n){if(oe(this.data_)){var r=this.data_,o=be(r,t,n);return null===o?null:new e(o)}var i=new Uint8Array(this.data_.buffer,t,n-t);return new e(i,!0)},e.getBlob=function(){for(var t=[],n=0;n<arguments.length;n++)t[n]=arguments[n];if(ie()){var r=t.map((function(t){return t instanceof e?t.data_:t}));return new e(ge.apply(null,r))}var o=t.map((function(e){return re(e)?L(U.RAW,e).data:e.data_})),i=0;o.forEach((function(e){i+=e.byteLength}));var s=new Uint8Array(i),a=0;return o.forEach((function(e){for(var t=0;t<e.length;t++)s[a++]=e[t]})),new e(s,!0)},e.prototype.uploadData=function(){return this.data_},e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ye(e){var t;try{t=JSON.parse(e)}catch(n){return null}return ne(t)?t:null}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function we(e){if(0===e.length)return null;var t=e.lastIndexOf("/");if(-1===t)return"";var n=e.slice(0,t);return n}function Re(e,t){var n=t.split("/").filter((function(e){return e.length>0})).join("/");return 0===e.length?n:e+"/"+n}function Oe(e){var t=e.lastIndexOf("/",e.length-2);return-1===t?e:e.slice(t+1)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ke(e,t){return t}var Te=function(){function e(e,t,n,r){this.server=e,this.local=t||e,this.writable=!!n,this.xform=r||ke}return e}(),Ce=null;function Se(e){return!re(e)||e.length<2?e:Oe(e)}function Ee(){if(Ce)return Ce;var e=[];function t(e,t){return Se(t)}e.push(new Te("bucket")),e.push(new Te("generation")),e.push(new Te("metageneration")),e.push(new Te("name","fullPath",!0));var n=new Te("name");function r(e,t){return void 0!==t?Number(t):t}n.xform=t,e.push(n);var o=new Te("size");return o.xform=r,e.push(o),e.push(new Te("timeCreated")),e.push(new Te("updated")),e.push(new Te("md5Hash",null,!0)),e.push(new Te("cacheControl",null,!0)),e.push(new Te("contentDisposition",null,!0)),e.push(new Te("contentEncoding",null,!0)),e.push(new Te("contentLanguage",null,!0)),e.push(new Te("contentType",null,!0)),e.push(new Te("metadata","customMetadata",!0)),Ce=e,Ce}function Pe(e,t){function n(){var n=e["bucket"],r=e["fullPath"],o=new Z(n,r);return t._makeStorageReference(o)}Object.defineProperty(e,"ref",{get:n})}function Ie(e,t,n){for(var r={type:"file"},o=n.length,i=0;i<o;i++){var s=n[i];r[s.local]=s.xform(r,t[s.server])}return Pe(r,e),r}function xe(e,t,n){var r=ye(t);if(null===r)return null;var o=r;return Ie(e,o,n)}function je(e,t,n){var r=ye(t);if(null===r)return null;if(!re(r["downloadTokens"]))return null;var o=r["downloadTokens"];if(0===o.length)return null;var i=encodeURIComponent,s=o.split(","),a=s.map((function(t){var r=e["bucket"],o=e["fullPath"],s="/b/"+i(r)+"/o/"+i(o),a=ae(s,n),u=ue({alt:"media",token:t});return a+u}));return a[0]}function Ue(e,t){for(var n={},r=t.length,o=0;o<r;o++){var i=t[o];i.writable&&(n[i.server]=e[i.local])}return JSON.stringify(n)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Ae="prefixes",Le="items";function ze(e,t,n){var r={prefixes:[],items:[],nextPageToken:n["nextPageToken"]};if(n[Ae])for(var o=0,i=n[Ae];o<i.length;o++){var s=i[o],a=s.replace(/\/$/,""),u=e._makeStorageReference(new Z(t,a));r.prefixes.push(u)}if(n[Le])for(var c=0,l=n[Le];c<l.length;c++){var h=l[c];u=e._makeStorageReference(new Z(t,h["name"]));r.items.push(u)}return r}function Ne(e,t,n){var r=ye(n);if(null===r)return null;var o=r;return ze(e,t,o)}var He=function(){function e(e,t,n,r){this.url=e,this.method=t,this.handler=n,this.timeout=r,this.urlParams={},this.headers={},this.body=null,this.errorHandler=null,this.progressCallback=null,this.successCodes=[200],this.additionalRetryCodes=[]}return e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function De(e){if(!e)throw p()}function Be(e,t){function n(n,r){var o=xe(e,r,t);return De(null!==o),o}return n}function Me(e,t){function n(n,r){var o=Ne(e,t,r);return De(null!==o),o}return n}function qe(e,t){function n(n,r){var o=xe(e,r,t);return De(null!==o),je(o,r,e.host)}return n}function Fe(e){function t(t,n){var r;return r=401===t.getStatus()?t.getResponseText().includes("Firebase App Check token is invalid")?g():_():402===t.getStatus()?v(e.bucket):403===t.getStatus()?b(e.path):n,r.serverResponse=n.serverResponse,r}return t}function Ge(e){var t=Fe(e);function n(n,r){var o=t(n,r);return 404===n.getStatus()&&(o=d(e.path)),o.serverResponse=r.serverResponse,o}return n}function We(e,t,n){var r=t.fullServerUrl(),o=ae(r,e.host),i="GET",s=e.maxOperationRetryTime,a=new He(o,i,Be(e,n),s);return a.errorHandler=Ge(t),a}function Xe(e,t,n,r,o){var i={};t.isRoot?i["prefix"]="":i["prefix"]=t.path+"/",n&&n.length>0&&(i["delimiter"]=n),r&&(i["pageToken"]=r),o&&(i["maxResults"]=o);var s=t.bucketOnlyServerUrl(),a=ae(s,e.host),u="GET",c=e.maxOperationRetryTime,l=new He(a,u,Me(e,t.bucket),c);return l.urlParams=i,l.errorHandler=Fe(t),l}function Ve(e,t,n){var r=t.fullServerUrl(),o=ae(r,e.host),i="GET",s=e.maxOperationRetryTime,a=new He(o,i,qe(e,n),s);return a.errorHandler=Ge(t),a}function Ke(e,t,n,r){var o=t.fullServerUrl(),i=ae(o,e.host),s="PATCH",a=Ue(n,r),u={"Content-Type":"application/json; charset=utf-8"},c=e.maxOperationRetryTime,l=new He(i,s,Be(e,r),c);return l.headers=u,l.body=a,l.errorHandler=Ge(t),l}function Je(e,t){var n=t.fullServerUrl(),r=ae(n,e.host),o="DELETE",i=e.maxOperationRetryTime;function s(e,t){}var a=new He(r,o,s,i);return a.successCodes=[200,204],a.errorHandler=Ge(t),a}function Ze(e,t){return e&&e["contentType"]||t&&t.type()||"application/octet-stream"}function $e(e,t,n){var r=Object.assign({},n);return r["fullPath"]=e.path,r["size"]=t.size(),r["contentType"]||(r["contentType"]=Ze(null,t)),r}function Ye(e,t,n,r,o){var i=t.bucketOnlyServerUrl(),s={"X-Goog-Upload-Protocol":"multipart"};function a(){for(var e="",t=0;t<2;t++)e+=Math.random().toString().slice(2);return e}var u=a();s["Content-Type"]="multipart/related; boundary="+u;var c=$e(t,r,o),l=Ue(c,n),h="--"+u+"\r\nContent-Type: application/json; charset=utf-8\r\n\r\n"+l+"\r\n--"+u+"\r\nContent-Type: "+c["contentType"]+"\r\n\r\n",f="\r\n--"+u+"--",p=me.getBlob(h,r,f);if(null===p)throw k();var d={name:c["fullPath"]},v=ae(i,e.host),_="POST",g=e.maxUploadRetryTime,b=new He(v,_,Be(e,n),g);return b.urlParams=d,b.headers=s,b.body=p.uploadData(),b.errorHandler=Fe(t),b}var Qe=function(){function e(e,t,n,r){this.current=e,this.total=t,this.finalized=!!n,this.metadata=r||null}return e}();function et(e,t){var n=null;try{n=e.getResponseHeader("X-Goog-Upload-Status")}catch(o){De(!1)}var r=t||["active"];return De(!!n&&-1!==r.indexOf(n)),n}function tt(e,t,n,r,o){var i=t.bucketOnlyServerUrl(),s=$e(t,r,o),a={name:s["fullPath"]},u=ae(i,e.host),c="POST",l={"X-Goog-Upload-Protocol":"resumable","X-Goog-Upload-Command":"start","X-Goog-Upload-Header-Content-Length":""+r.size(),"X-Goog-Upload-Header-Content-Type":s["contentType"],"Content-Type":"application/json; charset=utf-8"},h=Ue(s,n),f=e.maxUploadRetryTime;function p(e){var t;et(e);try{t=e.getResponseHeader("X-Goog-Upload-URL")}catch(n){De(!1)}return De(re(t)),t}var d=new He(u,c,p,f);return d.urlParams=a,d.headers=l,d.body=h,d.errorHandler=Fe(t),d}function nt(e,t,n,r){var o={"X-Goog-Upload-Command":"query"};function i(e){var t=et(e,["active","final"]),n=null;try{n=e.getResponseHeader("X-Goog-Upload-Size-Received")}catch(i){De(!1)}n||De(!1);var o=Number(n);return De(!isNaN(o)),new Qe(o,r.size(),"final"===t)}var s="POST",a=e.maxUploadRetryTime,u=new He(n,s,i,a);return u.headers=o,u.errorHandler=Fe(t),u}var rt=262144;function ot(e,t,n,r,o,i,s,a){var u=new Qe(0,0);if(s?(u.current=s.current,u.total=s.total):(u.current=0,u.total=r.size()),r.size()!==u.total)throw T();var c=u.total-u.current,l=c;o>0&&(l=Math.min(l,o));var h=u.current,f=h+l,p=l===c?"upload, finalize":"upload",d={"X-Goog-Upload-Command":p,"X-Goog-Upload-Offset":""+u.current},v=r.slice(h,f);if(null===v)throw k();function _(e,n){var o,s=et(e,["active","final"]),a=u.current+l,c=r.size();return o="final"===s?Be(t,i)(e,n):null,new Qe(a,c,"final"===s,o)}var g="POST",b=t.maxUploadRetryTime,m=new He(n,g,_,b);return m.headers=d,m.body=v.uploadData(),m.progressCallback=a||null,m.errorHandler=Fe(e),m}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var it=function(){function e(e,t,n){var r=te(e)||null!=t||null!=n;if(r)this.next=e,this.error=t,this.complete=n;else{var o=e;this.next=o.next,this.error=o.error,this.complete=o.complete}}return e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function st(e){return function(){for(var t=[],n=0;n<arguments.length;n++)t[n]=arguments[n];Promise.resolve().then((function(){return e.apply(void 0,t)}))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var at=function(){function e(e,t,n){var r=this;void 0===n&&(n=null),this._transferred=0,this._needToFetchStatus=!1,this._needToFetchMetadata=!1,this._observers=[],this._error=void 0,this._uploadUrl=void 0,this._request=void 0,this._chunkMultiplier=1,this._resolve=void 0,this._reject=void 0,this._ref=e,this._blob=t,this._metadata=n,this._mappings=Ee(),this._resumable=this._shouldDoResumable(this._blob),this._state="running",this._errorHandler=function(e){r._request=void 0,r._chunkMultiplier=1,e._codeEquals("canceled")?(r._needToFetchStatus=!0,r.completeTransitions_()):(r._error=e,r._transition("error"))},this._metadataErrorHandler=function(e){r._request=void 0,e._codeEquals("canceled")?r.completeTransitions_():(r._error=e,r._transition("error"))},this._promise=new Promise((function(e,t){r._resolve=e,r._reject=t,r._start()})),this._promise.then(null,(function(){}))}return e.prototype._makeProgressCallback=function(){var e=this,t=this._transferred;return function(n){return e._updateProgress(t+n)}},e.prototype._shouldDoResumable=function(e){return e.size()>262144},e.prototype._start=function(){"running"===this._state&&void 0===this._request&&(this._resumable?void 0===this._uploadUrl?this._createResumable():this._needToFetchStatus?this._fetchStatus():this._needToFetchMetadata?this._fetchMetadata():this._continueUpload():this._oneShotUpload())},e.prototype._resolveToken=function(e){var t=this;Promise.all([this._ref.storage._getAuthToken(),this._ref.storage._getAppCheckToken()]).then((function(n){var r=n[0],o=n[1];switch(t._state){case"running":e(r,o);break;case"canceling":t._transition("canceled");break;case"pausing":t._transition("paused");break}}))},e.prototype._createResumable=function(){var e=this;this._resolveToken((function(t,n){var r=tt(e._ref.storage,e._ref._location,e._mappings,e._blob,e._metadata),o=e._ref.storage._makeRequest(r,t,n);e._request=o,o.getPromise().then((function(t){e._request=void 0,e._uploadUrl=t,e._needToFetchStatus=!1,e.completeTransitions_()}),e._errorHandler)}))},e.prototype._fetchStatus=function(){var e=this,t=this._uploadUrl;this._resolveToken((function(n,r){var o=nt(e._ref.storage,e._ref._location,t,e._blob),i=e._ref.storage._makeRequest(o,n,r);e._request=i,i.getPromise().then((function(t){t=t,e._request=void 0,e._updateProgress(t.current),e._needToFetchStatus=!1,t.finalized&&(e._needToFetchMetadata=!0),e.completeTransitions_()}),e._errorHandler)}))},e.prototype._continueUpload=function(){var e=this,t=rt*this._chunkMultiplier,n=new Qe(this._transferred,this._blob.size()),r=this._uploadUrl;this._resolveToken((function(o,i){var s;try{s=ot(e._ref._location,e._ref.storage,r,e._blob,t,e._mappings,n,e._makeProgressCallback())}catch(u){return e._error=u,void e._transition("error")}var a=e._ref.storage._makeRequest(s,o,i);e._request=a,a.getPromise().then((function(t){e._increaseMultiplier(),e._request=void 0,e._updateProgress(t.current),t.finalized?(e._metadata=t.metadata,e._transition("success")):e.completeTransitions_()}),e._errorHandler)}))},e.prototype._increaseMultiplier=function(){var e=rt*this._chunkMultiplier;e<33554432&&(this._chunkMultiplier*=2)},e.prototype._fetchMetadata=function(){var e=this;this._resolveToken((function(t,n){var r=We(e._ref.storage,e._ref._location,e._mappings),o=e._ref.storage._makeRequest(r,t,n);e._request=o,o.getPromise().then((function(t){e._request=void 0,e._metadata=t,e._transition("success")}),e._metadataErrorHandler)}))},e.prototype._oneShotUpload=function(){var e=this;this._resolveToken((function(t,n){var r=Ye(e._ref.storage,e._ref._location,e._mappings,e._blob,e._metadata),o=e._ref.storage._makeRequest(r,t,n);e._request=o,o.getPromise().then((function(t){e._request=void 0,e._metadata=t,e._updateProgress(e._blob.size()),e._transition("success")}),e._errorHandler)}))},e.prototype._updateProgress=function(e){var t=this._transferred;this._transferred=e,this._transferred!==t&&this._notifyObservers()},e.prototype._transition=function(e){if(this._state!==e)switch(e){case"canceling":this._state=e,void 0!==this._request&&this._request.cancel();break;case"pausing":this._state=e,void 0!==this._request&&this._request.cancel();break;case"running":var t="paused"===this._state;this._state=e,t&&(this._notifyObservers(),this._start());break;case"paused":this._state=e,this._notifyObservers();break;case"canceled":this._error=y(),this._state=e,this._notifyObservers();break;case"error":this._state=e,this._notifyObservers();break;case"success":this._state=e,this._notifyObservers();break}},e.prototype.completeTransitions_=function(){switch(this._state){case"pausing":this._transition("paused");break;case"canceling":this._transition("canceled");break;case"running":this._start();break}},Object.defineProperty(e.prototype,"snapshot",{get:function(){var e=X(this._state);return{bytesTransferred:this._transferred,totalBytes:this._blob.size(),state:e,metadata:this._metadata,task:this,ref:this._ref}},enumerable:!1,configurable:!0}),e.prototype.on=function(e,t,n,r){var o=this,i=new it(t,n,r);return this._addObserver(i),function(){o._removeObserver(i)}},e.prototype.then=function(e,t){return this._promise.then(e,t)},e.prototype.catch=function(e){return this.then(null,e)},e.prototype._addObserver=function(e){this._observers.push(e),this._notifyObserver(e)},e.prototype._removeObserver=function(e){var t=this._observers.indexOf(e);-1!==t&&this._observers.splice(t,1)},e.prototype._notifyObservers=function(){var e=this;this._finishPromise();var t=this._observers.slice();t.forEach((function(t){e._notifyObserver(t)}))},e.prototype._finishPromise=function(){if(void 0!==this._resolve){var e=!0;switch(X(this._state)){case W.SUCCESS:st(this._resolve.bind(null,this.snapshot))();break;case W.CANCELED:case W.ERROR:var t=this._reject;st(t.bind(null,this._error))();break;default:e=!1;break}e&&(this._resolve=void 0,this._reject=void 0)}},e.prototype._notifyObserver=function(e){var t=X(this._state);switch(t){case W.RUNNING:case W.PAUSED:e.next&&st(e.next.bind(e,this.snapshot))();break;case W.SUCCESS:e.complete&&st(e.complete.bind(e))();break;case W.CANCELED:case W.ERROR:e.error&&st(e.error.bind(e,this._error))();break;default:e.error&&st(e.error.bind(e,this._error))()}},e.prototype.resume=function(){var e="paused"===this._state||"pausing"===this._state;return e&&this._transition("running"),e},e.prototype.pause=function(){var e="running"===this._state;return e&&this._transition("pausing"),e},e.prototype.cancel=function(){var e="running"===this._state||"pausing"===this._state;return e&&this._transition("canceling"),e},e}(),ut=function(){function e(e,t){this._service=e,this._location=t instanceof Z?t:Z.makeFromUrl(t,e.host)}return e.prototype.toString=function(){return"gs://"+this._location.bucket+"/"+this._location.path},e.prototype._newRef=function(t,n){return new e(t,n)},Object.defineProperty(e.prototype,"root",{get:function(){var e=new Z(this._location.bucket,"");return this._newRef(this._service,e)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"bucket",{get:function(){return this._location.bucket},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"fullPath",{get:function(){return this._location.path},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"name",{get:function(){return Oe(this._location.path)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"storage",{get:function(){return this._service},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"parent",{get:function(){var t=we(this._location.path);if(null===t)return null;var n=new Z(this._location.bucket,t);return new e(this._service,n)},enumerable:!1,configurable:!0}),e.prototype._throwIfRoot=function(e){if(""===this._location.path)throw P(e)},e}();
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ct(e,t,n){return e._throwIfRoot("uploadBytesResumable"),new at(e,new me(t),n)}function lt(e){var t={prefixes:[],items:[]};return ht(e,t).then((function(){return t}))}function ht(e,t,n){return Object(o["b"])(this,void 0,void 0,(function(){var r,i,s,a;return Object(o["d"])(this,(function(o){switch(o.label){case 0:return r={pageToken:n},[4,ft(e,r)];case 1:return i=o.sent(),(s=t.prefixes).push.apply(s,i.prefixes),(a=t.items).push.apply(a,i.items),null==i.nextPageToken?[3,3]:[4,ht(e,t,i.nextPageToken)];case 2:o.sent(),o.label=3;case 3:return[2]}}))}))}function ft(e,t){return Object(o["b"])(this,void 0,void 0,(function(){var n,r;return Object(o["d"])(this,(function(o){switch(o.label){case 0:return null!=t&&"number"===typeof t.maxResults&&se("options.maxResults",1,1e3,t.maxResults),n=t||{},r=Xe(e.storage,e._location,"/",n.pageToken,n.maxResults),[4,e.storage.makeRequestWithTokens(r)];case 1:return[2,o.sent().getPromise()]}}))}))}function pt(e){return Object(o["b"])(this,void 0,void 0,(function(){var t;return Object(o["d"])(this,(function(n){switch(n.label){case 0:return e._throwIfRoot("getMetadata"),t=We(e.storage,e._location,Ee()),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,n.sent().getPromise()]}}))}))}function dt(e,t){return Object(o["b"])(this,void 0,void 0,(function(){var n;return Object(o["d"])(this,(function(r){switch(r.label){case 0:return e._throwIfRoot("updateMetadata"),n=Ke(e.storage,e._location,t,Ee()),[4,e.storage.makeRequestWithTokens(n)];case 1:return[2,r.sent().getPromise()]}}))}))}function vt(e){return Object(o["b"])(this,void 0,void 0,(function(){var t;return Object(o["d"])(this,(function(n){switch(n.label){case 0:return e._throwIfRoot("getDownloadURL"),t=Ve(e.storage,e._location,Ee()),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,n.sent().getPromise().then((function(e){if(null===e)throw C();return e}))]}}))}))}function _t(e){return Object(o["b"])(this,void 0,void 0,(function(){var t;return Object(o["d"])(this,(function(n){switch(n.label){case 0:return e._throwIfRoot("deleteObject"),t=Je(e.storage,e._location),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,n.sent().getPromise()]}}))}))}function gt(e,t){var n=Re(e._location.path,t),r=new Z(e._location.bucket,n);return new ut(e.storage,r)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bt(e){return/^[A-Za-z]+:\/\//.test(e)}function mt(e,t){return new ut(e,t)}function yt(e,t){if(e instanceof kt){var n=e;if(null==n._bucket)throw O();var r=new ut(n,n._bucket);return null!=t?yt(r,t):r}if(void 0!==t){if(t.includes(".."))throw S('`path` param cannot contain ".."');return gt(e,t)}return e}function wt(e,t){if(t&&bt(t)){if(e instanceof kt)return mt(e,t);throw S("To use ref(service, url), the first argument must be a Storage instance.")}return yt(e,t)}function Rt(e,t){var n=null===t||void 0===t?void 0:t[u];return null==n?null:Z.makeFromBucketSpec(n,e)}function Ot(e,t,n){e.host="http://"+t+":"+n}var kt=function(){function e(e,t,n,r,o,i){this.app=e,this._authProvider=t,this._appCheckProvider=n,this._pool=r,this._url=o,this._firebaseVersion=i,this._bucket=null,this._host=a,this._appId=null,this._deleted=!1,this._maxOperationRetryTime=c,this._maxUploadRetryTime=l,this._requests=new Set,this._bucket=null!=o?Z.makeFromBucketSpec(o,this._host):Rt(this._host,this.app.options)}return Object.defineProperty(e.prototype,"host",{get:function(){return this._host},set:function(e){this._host=e,null!=this._url?this._bucket=Z.makeFromBucketSpec(this._url,e):this._bucket=Rt(e,this.app.options)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxUploadRetryTime",{get:function(){return this._maxUploadRetryTime},set:function(e){se("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxOperationRetryTime",{get:function(){return this._maxOperationRetryTime},set:function(e){se("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e},enumerable:!1,configurable:!0}),e.prototype._getAuthToken=function(){return Object(o["b"])(this,void 0,void 0,(function(){var e,t;return Object(o["d"])(this,(function(n){switch(n.label){case 0:return e=this._authProvider.getImmediate({optional:!0}),e?[4,e.getToken()]:[3,2];case 1:if(t=n.sent(),null!==t)return[2,t.accessToken];n.label=2;case 2:return[2,null]}}))}))},e.prototype._getAppCheckToken=function(){return Object(o["b"])(this,void 0,void 0,(function(){var e,t;return Object(o["d"])(this,(function(n){switch(n.label){case 0:return e=this._appCheckProvider.getImmediate({optional:!0}),e?[4,e.getToken()]:[3,2];case 1:return t=n.sent(),[2,t.token];case 2:return[2,null]}}))}))},e.prototype._delete=function(){return this._deleted=!0,this._requests.forEach((function(e){return e.cancel()})),this._requests.clear(),Promise.resolve()},e.prototype._makeStorageReference=function(e){return new ut(this,e)},e.prototype._makeRequest=function(e,t,n){var r=this;if(this._deleted)return new $(E());var o=ve(e,this._appId,t,n,this._pool,this._firebaseVersion);return this._requests.add(o),o.getPromise().then((function(){return r._requests.delete(o)}),(function(){return r._requests.delete(o)})),o},e.prototype.makeRequestWithTokens=function(e){return Object(o["b"])(this,void 0,void 0,(function(){var t,n,r;return Object(o["d"])(this,(function(o){switch(o.label){case 0:return[4,Promise.all([this._getAuthToken(),this._getAppCheckToken()])];case 1:return t=o.sent(),n=t[0],r=t[1],[2,this._makeRequest(e,n,r)]}}))}))},e}();
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Tt(e,t,n){return e=Object(i["h"])(e),ct(e,t,n)}function Ct(e){return e=Object(i["h"])(e),pt(e)}function St(e,t){return e=Object(i["h"])(e),dt(e,t)}function Et(e,t){return e=Object(i["h"])(e),ft(e,t)}function Pt(e){return e=Object(i["h"])(e),lt(e)}function It(e){return e=Object(i["h"])(e),vt(e)}function xt(e){return e=Object(i["h"])(e),_t(e)}function jt(e,t){return e=Object(i["h"])(e),wt(e,t)}function Ut(e,t){return gt(e,t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var At=function(){function e(e,t,n){this._delegate=e,this.task=t,this.ref=n}return Object.defineProperty(e.prototype,"bytesTransferred",{get:function(){return this._delegate.bytesTransferred},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"metadata",{get:function(){return this._delegate.metadata},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"state",{get:function(){return this._delegate.state},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"totalBytes",{get:function(){return this._delegate.totalBytes},enumerable:!1,configurable:!0}),e}(),Lt=function(){function e(e,t){this._delegate=e,this._ref=t,this.cancel=this._delegate.cancel.bind(this._delegate),this.catch=this._delegate.catch.bind(this._delegate),this.pause=this._delegate.pause.bind(this._delegate),this.resume=this._delegate.resume.bind(this._delegate)}return Object.defineProperty(e.prototype,"snapshot",{get:function(){return new At(this._delegate.snapshot,this,this._ref)},enumerable:!1,configurable:!0}),e.prototype.then=function(e,t){var n=this;return this._delegate.then((function(t){if(e)return e(new At(t,n,n._ref))}),t)},e.prototype.on=function(e,t,n,r){var o=this,i=void 0;return t&&(i="function"===typeof t?function(e){return t(new At(e,o,o._ref))}:{next:t.next?function(e){return t.next(new At(e,o,o._ref))}:void 0,complete:t.complete||void 0,error:t.error||void 0}),this._delegate.on(e,i,n||void 0,r||void 0)},e}(),zt=function(){function e(e,t){this._delegate=e,this._service=t}return Object.defineProperty(e.prototype,"prefixes",{get:function(){var e=this;return this._delegate.prefixes.map((function(t){return new Nt(t,e._service)}))},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"items",{get:function(){var e=this;return this._delegate.items.map((function(t){return new Nt(t,e._service)}))},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"nextPageToken",{get:function(){return this._delegate.nextPageToken||null},enumerable:!1,configurable:!0}),e}(),Nt=function(){function e(e,t){this._delegate=e,this.storage=t}return Object.defineProperty(e.prototype,"name",{get:function(){return this._delegate.name},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"bucket",{get:function(){return this._delegate.bucket},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"fullPath",{get:function(){return this._delegate.fullPath},enumerable:!1,configurable:!0}),e.prototype.toString=function(){return this._delegate.toString()},e.prototype.child=function(t){var n=Ut(this._delegate,t);return new e(n,this.storage)},Object.defineProperty(e.prototype,"root",{get:function(){return new e(this._delegate.root,this.storage)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"parent",{get:function(){var t=this._delegate.parent;return null==t?null:new e(t,this.storage)},enumerable:!1,configurable:!0}),e.prototype.put=function(e,t){return this._throwIfRoot("put"),new Lt(Tt(this._delegate,e,t),this)},e.prototype.putString=function(e,t,n){void 0===t&&(t=U.RAW),this._throwIfRoot("putString");var r=L(t,e),i=Object(o["a"])({},n);return null==i["contentType"]&&null!=r.contentType&&(i["contentType"]=r.contentType),new Lt(new at(this._delegate,new me(r.data,!0),i),this)},e.prototype.listAll=function(){var e=this;return Pt(this._delegate).then((function(t){return new zt(t,e.storage)}))},e.prototype.list=function(e){var t=this;return Et(this._delegate,e||void 0).then((function(e){return new zt(e,t.storage)}))},e.prototype.getMetadata=function(){return Ct(this._delegate)},e.prototype.updateMetadata=function(e){return St(this._delegate,e)},e.prototype.getDownloadURL=function(){return It(this._delegate)},e.prototype.delete=function(){return this._throwIfRoot("delete"),xt(this._delegate)},e.prototype._throwIfRoot=function(e){if(""===this._delegate._location.path)throw P(e)},e}(),Ht=function(){function e(e,t){var n=this;this.app=e,this._delegate=t,this.INTERNAL={delete:function(){return n._delegate._delete()}}}return Object.defineProperty(e.prototype,"maxOperationRetryTime",{get:function(){return this._delegate.maxOperationRetryTime},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxUploadRetryTime",{get:function(){return this._delegate.maxUploadRetryTime},enumerable:!1,configurable:!0}),e.prototype.ref=function(e){if(bt(e))throw S("ref() expected a child path but got a URL, use refFromURL instead.");return new Nt(jt(this._delegate,e),this)},e.prototype.refFromURL=function(e){if(!bt(e))throw S("refFromURL() expected a full URL but got a child path, use ref() instead.");try{Z.makeFromUrl(e,this._delegate.host)}catch(t){throw S("refFromUrl() expected a valid full URL but got an invalid one.")}return new Nt(jt(this._delegate,e),this)},e.prototype.setMaxUploadRetryTime=function(e){this._delegate.maxUploadRetryTime=e},e.prototype.setMaxOperationRetryTime=function(e){this._delegate.maxOperationRetryTime=e},e.prototype.useEmulator=function(e,t){Ot(this._delegate,e,t)},e}(),Dt="@firebase/storage",Bt="0.5.6",Mt="storage";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qt(e,t){var n=t.instanceIdentifier,o=e.getProvider("app").getImmediate(),i=e.getProvider("auth-internal"),s=e.getProvider("app-check-internal"),a=new Ht(o,new kt(o,i,s,new J,n,r["a"].SDK_VERSION));return a}function Ft(e){var t={TaskState:W,TaskEvent:G,StringFormat:U,Storage:kt,Reference:Nt};e.INTERNAL.registerComponent(new s["a"](Mt,qt,"PUBLIC").setServiceProps(t).setMultipleInstances(!0)),e.registerVersion(Dt,Bt)}Ft(r["a"])},5363:function(e,t,n){},a8e9:function(e,t,n){"use strict";(function(e){n.d(t,"a",(function(){return c})),n.d(t,"b",(function(){return d})),n.d(t,"c",(function(){return p})),n.d(t,"d",(function(){return g})),n.d(t,"e",(function(){return b})),n.d(t,"f",(function(){return s})),n.d(t,"g",(function(){return a})),n.d(t,"h",(function(){return R})),n.d(t,"i",(function(){return h})),n.d(t,"j",(function(){return l}));var r=n("9ab4"),o=function(e){for(var t=[],n=0,r=0;r<e.length;r++){var o=e.charCodeAt(r);o<128?t[n++]=o:o<2048?(t[n++]=o>>6|192,t[n++]=63&o|128):55296===(64512&o)&&r+1<e.length&&56320===(64512&e.charCodeAt(r+1))?(o=65536+((1023&o)<<10)+(1023&e.charCodeAt(++r)),t[n++]=o>>18|240,t[n++]=o>>12&63|128,t[n++]=o>>6&63|128,t[n++]=63&o|128):(t[n++]=o>>12|224,t[n++]=o>>6&63|128,t[n++]=63&o|128)}return t},i=function(e){var t=[],n=0,r=0;while(n<e.length){var o=e[n++];if(o<128)t[r++]=String.fromCharCode(o);else if(o>191&&o<224){var i=e[n++];t[r++]=String.fromCharCode((31&o)<<6|63&i)}else if(o>239&&o<365){i=e[n++];var s=e[n++],a=e[n++],u=((7&o)<<18|(63&i)<<12|(63&s)<<6|63&a)-65536;t[r++]=String.fromCharCode(55296+(u>>10)),t[r++]=String.fromCharCode(56320+(1023&u))}else{i=e[n++],s=e[n++];t[r++]=String.fromCharCode((15&o)<<12|(63&i)<<6|63&s)}}return t.join("")};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function s(e){return a(void 0,e)}function a(e,t){if(!(t instanceof Object))return t;switch(t.constructor){case Date:var n=t;return new Date(n.getTime());case Object:void 0===e&&(e={});break;case Array:e=[];break;default:return t}for(var r in t)t.hasOwnProperty(r)&&u(r)&&(e[r]=a(e[r],t[r]));return e}function u(e){return"__proto__"!==e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var c=function(){function e(){var e=this;this.reject=function(){},this.resolve=function(){},this.promise=new Promise((function(t,n){e.resolve=t,e.reject=n}))}return e.prototype.wrapCallback=function(e){var t=this;return function(n,r){n?t.reject(n):t.resolve(r),"function"===typeof e&&(t.promise.catch((function(){})),1===e.length?e(n):e(n,r))}},e}();
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function l(){try{return"[object process]"===Object.prototype.toString.call(e.process)}catch(t){return!1}}function h(){return"object"===typeof self&&self.self===self}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var f="FirebaseError",p=function(e){function t(n,r,o){var i=e.call(this,r)||this;return i.code=n,i.customData=o,i.name=f,Object.setPrototypeOf(i,t.prototype),Error.captureStackTrace&&Error.captureStackTrace(i,d.prototype.create),i}return Object(r["c"])(t,e),t}(Error),d=function(){function e(e,t,n){this.service=e,this.serviceName=t,this.errors=n}return e.prototype.create=function(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];var r=t[0]||{},o=this.service+"/"+e,i=this.errors[e],s=i?v(i,r):"Error",a=this.serviceName+": "+s+" ("+o+").",u=new p(o,a,r);return u},e}();function v(e,t){return e.replace(_,(function(e,n){var r=t[n];return null!=r?String(r):"<"+n+"?>"}))}var _=/\{\$([^}]+)}/g;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function g(e,t){return Object.prototype.hasOwnProperty.call(e,t)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
(function(){function e(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=64,this.pad_[0]=128;for(var e=1;e<this.blockSize;++e)this.pad_[e]=0;this.reset()}e.prototype.reset=function(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0},e.prototype.compress_=function(e,t){t||(t=0);var n=this.W_;if("string"===typeof e)for(var r=0;r<16;r++)n[r]=e.charCodeAt(t)<<24|e.charCodeAt(t+1)<<16|e.charCodeAt(t+2)<<8|e.charCodeAt(t+3),t+=4;else for(r=0;r<16;r++)n[r]=e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3],t+=4;for(r=16;r<80;r++){var o=n[r-3]^n[r-8]^n[r-14]^n[r-16];n[r]=4294967295&(o<<1|o>>>31)}var i,s,a=this.chain_[0],u=this.chain_[1],c=this.chain_[2],l=this.chain_[3],h=this.chain_[4];for(r=0;r<80;r++){r<40?r<20?(i=l^u&(c^l),s=1518500249):(i=u^c^l,s=1859775393):r<60?(i=u&c|l&(u|c),s=2400959708):(i=u^c^l,s=3395469782);o=(a<<5|a>>>27)+i+h+s+n[r]&4294967295;h=l,l=c,c=4294967295&(u<<30|u>>>2),u=a,a=o}this.chain_[0]=this.chain_[0]+a&4294967295,this.chain_[1]=this.chain_[1]+u&4294967295,this.chain_[2]=this.chain_[2]+c&4294967295,this.chain_[3]=this.chain_[3]+l&4294967295,this.chain_[4]=this.chain_[4]+h&4294967295},e.prototype.update=function(e,t){if(null!=e){void 0===t&&(t=e.length);var n=t-this.blockSize,r=0,o=this.buf_,i=this.inbuf_;while(r<t){if(0===i)while(r<=n)this.compress_(e,r),r+=this.blockSize;if("string"===typeof e){while(r<t)if(o[i]=e.charCodeAt(r),++i,++r,i===this.blockSize){this.compress_(o),i=0;break}}else while(r<t)if(o[i]=e[r],++i,++r,i===this.blockSize){this.compress_(o),i=0;break}}this.inbuf_=i,this.total_+=t}},e.prototype.digest=function(){var e=[],t=8*this.total_;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(var n=this.blockSize-1;n>=56;n--)this.buf_[n]=255&t,t/=256;this.compress_(this.buf_);var r=0;for(n=0;n<5;n++)for(var o=24;o>=0;o-=8)e[r]=this.chain_[n]>>o&255,++r;return e}})();function b(e,t){var n=new m(e,t);return n.subscribe.bind(n)}var m=function(){function e(e,t){var n=this;this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then((function(){e(n)})).catch((function(e){n.error(e)}))}return e.prototype.next=function(e){this.forEachObserver((function(t){t.next(e)}))},e.prototype.error=function(e){this.forEachObserver((function(t){t.error(e)})),this.close(e)},e.prototype.complete=function(){this.forEachObserver((function(e){e.complete()})),this.close()},e.prototype.subscribe=function(e,t,n){var r,o=this;if(void 0===e&&void 0===t&&void 0===n)throw new Error("Missing Observer.");r=y(e,["next","error","complete"])?e:{next:e,error:t,complete:n},void 0===r.next&&(r.next=w),void 0===r.error&&(r.error=w),void 0===r.complete&&(r.complete=w);var i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then((function(){try{o.finalError?r.error(o.finalError):r.complete()}catch(e){}})),this.observers.push(r),i},e.prototype.unsubscribeOne=function(e){void 0!==this.observers&&void 0!==this.observers[e]&&(delete this.observers[e],this.observerCount-=1,0===this.observerCount&&void 0!==this.onNoObservers&&this.onNoObservers(this))},e.prototype.forEachObserver=function(e){if(!this.finalized)for(var t=0;t<this.observers.length;t++)this.sendOne(t,e)},e.prototype.sendOne=function(e,t){var n=this;this.task.then((function(){if(void 0!==n.observers&&void 0!==n.observers[e])try{t(n.observers[e])}catch(r){"undefined"!==typeof console&&console.error&&console.error(r)}}))},e.prototype.close=function(e){var t=this;this.finalized||(this.finalized=!0,void 0!==e&&(this.finalError=e),this.task.then((function(){t.observers=void 0,t.onNoObservers=void 0})))},e}();function y(e,t){if("object"!==typeof e||null===e)return!1;for(var n=0,r=t;n<r.length;n++){var o=r[n];if(o in e&&"function"===typeof e[o])return!0}return!1}function w(){}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function R(e){return e&&e._delegate?e._delegate:e}}).call(this,n("c8ba"))},abfd:function(e,t,n){"use strict";
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
function r(){for(var e=0,t=0,n=arguments.length;t<n;t++)e+=arguments[t].length;var r=Array(e),o=0;for(t=0;t<n;t++)for(var i=arguments[t],s=0,a=i.length;s<a;s++,o++)r[o]=i[s];return r}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var o;n.d(t,"a",(function(){return h})),n.d(t,"b",(function(){return f})),n.d(t,"c",(function(){return p}));var i,s=[];(function(e){e[e["DEBUG"]=0]="DEBUG",e[e["VERBOSE"]=1]="VERBOSE",e[e["INFO"]=2]="INFO",e[e["WARN"]=3]="WARN",e[e["ERROR"]=4]="ERROR",e[e["SILENT"]=5]="SILENT"})(i||(i={}));var a={debug:i.DEBUG,verbose:i.VERBOSE,info:i.INFO,warn:i.WARN,error:i.ERROR,silent:i.SILENT},u=i.INFO,c=(o={},o[i.DEBUG]="log",o[i.VERBOSE]="log",o[i.INFO]="info",o[i.WARN]="warn",o[i.ERROR]="error",o),l=function(e,t){for(var n=[],o=2;o<arguments.length;o++)n[o-2]=arguments[o];if(!(t<e.logLevel)){var i=(new Date).toISOString(),s=c[t];if(!s)throw new Error("Attempted to log a message with an invalid logType (value: "+t+")");console[s].apply(console,r(["["+i+"]  "+e.name+":"],n))}},h=function(){function e(e){this.name=e,this._logLevel=u,this._logHandler=l,this._userLogHandler=null,s.push(this)}return Object.defineProperty(e.prototype,"logLevel",{get:function(){return this._logLevel},set:function(e){if(!(e in i))throw new TypeError('Invalid value "'+e+'" assigned to `logLevel`');this._logLevel=e},enumerable:!1,configurable:!0}),e.prototype.setLogLevel=function(e){this._logLevel="string"===typeof e?a[e]:e},Object.defineProperty(e.prototype,"logHandler",{get:function(){return this._logHandler},set:function(e){if("function"!==typeof e)throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"userLogHandler",{get:function(){return this._userLogHandler},set:function(e){this._userLogHandler=e},enumerable:!1,configurable:!0}),e.prototype.debug=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,i.DEBUG],e)),this._logHandler.apply(this,r([this,i.DEBUG],e))},e.prototype.log=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,i.VERBOSE],e)),this._logHandler.apply(this,r([this,i.VERBOSE],e))},e.prototype.info=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,i.INFO],e)),this._logHandler.apply(this,r([this,i.INFO],e))},e.prototype.warn=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,i.WARN],e)),this._logHandler.apply(this,r([this,i.WARN],e))},e.prototype.error=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,i.ERROR],e)),this._logHandler.apply(this,r([this,i.ERROR],e))},e}();function f(e){s.forEach((function(t){t.setLogLevel(e)}))}function p(e,t){for(var n=function(n){var r=null;t&&t.level&&(r=a[t.level]),n.userLogHandler=null===e?null:function(t,n){for(var o=[],s=2;s<arguments.length;s++)o[s-2]=arguments[s];var a=o.map((function(e){if(null==e)return null;if("string"===typeof e)return e;if("number"===typeof e||"boolean"===typeof e)return e.toString();if(e instanceof Error)return e.message;try{return JSON.stringify(e)}catch(t){return null}})).filter((function(e){return e})).join(" ");n>=(null!==r&&void 0!==r?r:t.logLevel)&&e({level:i[n].toLowerCase(),message:a,args:o,type:t.name})}},r=0,o=s;r<o.length;r++){var u=o[r];n(u)}}},ffa6:function(e,t,n){"use strict";n.d(t,"a",(function(){return i})),n.d(t,"b",(function(){return l}));var r=n("9ab4"),o=n("a8e9"),i=function(){function e(e,t,n){this.name=e,this.instanceFactory=t,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}return e.prototype.setInstantiationMode=function(e){return this.instantiationMode=e,this},e.prototype.setMultipleInstances=function(e){return this.multipleInstances=e,this},e.prototype.setServiceProps=function(e){return this.serviceProps=e,this},e.prototype.setInstanceCreatedCallback=function(e){return this.onInstanceCreated=e,this},e}(),s="[DEFAULT]",a=function(){function e(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.onInitCallbacks=new Map}return e.prototype.get=function(e){var t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){var n=new o["a"];if(this.instancesDeferred.set(t,n),this.isInitialized(t)||this.shouldAutoInitialize())try{var r=this.getOrInitializeService({instanceIdentifier:t});r&&n.resolve(r)}catch(i){}}return this.instancesDeferred.get(t).promise},e.prototype.getImmediate=function(e){var t,n=this.normalizeInstanceIdentifier(null===e||void 0===e?void 0:e.identifier),r=null!==(t=null===e||void 0===e?void 0:e.optional)&&void 0!==t&&t;if(!this.isInitialized(n)&&!this.shouldAutoInitialize()){if(r)return null;throw Error("Service "+this.name+" is not available")}try{return this.getOrInitializeService({instanceIdentifier:n})}catch(o){if(r)return null;throw o}},e.prototype.getComponent=function(){return this.component},e.prototype.setComponent=function(e){var t,n;if(e.name!==this.name)throw Error("Mismatching Component "+e.name+" for Provider "+this.name+".");if(this.component)throw Error("Component for "+this.name+" has already been provided");if(this.component=e,this.shouldAutoInitialize()){if(c(e))try{this.getOrInitializeService({instanceIdentifier:s})}catch(p){}try{for(var o=Object(r["g"])(this.instancesDeferred.entries()),i=o.next();!i.done;i=o.next()){var a=Object(r["e"])(i.value,2),u=a[0],l=a[1],h=this.normalizeInstanceIdentifier(u);try{var f=this.getOrInitializeService({instanceIdentifier:h});l.resolve(f)}catch(p){}}}catch(d){t={error:d}}finally{try{i&&!i.done&&(n=o.return)&&n.call(o)}finally{if(t)throw t.error}}}},e.prototype.clearInstance=function(e){void 0===e&&(e=s),this.instancesDeferred.delete(e),this.instances.delete(e)},e.prototype.delete=function(){return Object(r["b"])(this,void 0,void 0,(function(){var e;return Object(r["d"])(this,(function(t){switch(t.label){case 0:return e=Array.from(this.instances.values()),[4,Promise.all(Object(r["f"])(Object(r["f"])([],Object(r["e"])(e.filter((function(e){return"INTERNAL"in e})).map((function(e){return e.INTERNAL.delete()})))),Object(r["e"])(e.filter((function(e){return"_delete"in e})).map((function(e){return e._delete()})))))];case 1:return t.sent(),[2]}}))}))},e.prototype.isComponentSet=function(){return null!=this.component},e.prototype.isInitialized=function(e){return void 0===e&&(e=s),this.instances.has(e)},e.prototype.initialize=function(e){var t,n;void 0===e&&(e={});var o=e.options,i=void 0===o?{}:o,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(this.name+"("+s+") has already been initialized");if(!this.isComponentSet())throw Error("Component "+this.name+" has not been registered yet");var a=this.getOrInitializeService({instanceIdentifier:s,options:i});try{for(var u=Object(r["g"])(this.instancesDeferred.entries()),c=u.next();!c.done;c=u.next()){var l=Object(r["e"])(c.value,2),h=l[0],f=l[1],p=this.normalizeInstanceIdentifier(h);s===p&&f.resolve(a)}}catch(d){t={error:d}}finally{try{c&&!c.done&&(n=u.return)&&n.call(u)}finally{if(t)throw t.error}}return a},e.prototype.onInit=function(e,t){var n,r=this.normalizeInstanceIdentifier(t),o=null!==(n=this.onInitCallbacks.get(r))&&void 0!==n?n:new Set;o.add(e),this.onInitCallbacks.set(r,o);var i=this.instances.get(r);return i&&e(i,r),function(){o.delete(e)}},e.prototype.invokeOnInitCallbacks=function(e,t){var n,o,i=this.onInitCallbacks.get(t);if(i)try{for(var s=Object(r["g"])(i),a=s.next();!a.done;a=s.next()){var u=a.value;try{u(e,t)}catch(c){}}}catch(l){n={error:l}}finally{try{a&&!a.done&&(o=s.return)&&o.call(s)}finally{if(n)throw n.error}}},e.prototype.getOrInitializeService=function(e){var t=e.instanceIdentifier,n=e.options,r=void 0===n?{}:n,o=this.instances.get(t);if(!o&&this.component&&(o=this.component.instanceFactory(this.container,{instanceIdentifier:u(t),options:r}),this.instances.set(t,o),this.invokeOnInitCallbacks(o,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,o)}catch(i){}return o||null},e.prototype.normalizeInstanceIdentifier=function(e){return void 0===e&&(e=s),this.component?this.component.multipleInstances?e:s:e},e.prototype.shouldAutoInitialize=function(){return!!this.component&&"EXPLICIT"!==this.component.instantiationMode},e}();function u(e){return e===s?void 0:e}function c(e){return"EAGER"===e.instantiationMode}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var l=function(){function e(e){this.name=e,this.providers=new Map}return e.prototype.addComponent=function(e){var t=this.getProvider(e.name);if(t.isComponentSet())throw new Error("Component "+e.name+" has already been registered with "+this.name);t.setComponent(e)},e.prototype.addOrOverwriteComponent=function(e){var t=this.getProvider(e.name);t.isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)},e.prototype.getProvider=function(e){if(this.providers.has(e))return this.providers.get(e);var t=new a(e,this);return this.providers.set(e,t),t},e.prototype.getProviders=function(){return Array.from(this.providers.values())},e}()}}]);