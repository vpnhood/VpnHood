namespace VpnHood.AccessServer.HostProviders.Ovh.Dto;

internal class CartItemId
{
    public required int ItemId { get; set; }
}