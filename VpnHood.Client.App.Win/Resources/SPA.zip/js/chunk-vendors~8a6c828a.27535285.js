(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-vendors~8a6c828a"],{"2e66":function(e,t,n){"use strict";var r=n("cc84"),i=n("9ab4"),o=n("a8e9"),s=n("ffa6"),a="firebasestorage.googleapis.com",u="storageBucket",c=12e4,l=6e5,h=function(e){function t(n,r){var i=e.call(this,f(n),"Firebase Storage: "+r+" ("+f(n)+")")||this;return i.customData={serverResponse:null},i._baseMessage=i.message,Object.setPrototypeOf(i,t.prototype),i}return Object(i["c"])(t,e),t.prototype._codeEquals=function(e){return f(e)===this.code},Object.defineProperty(t.prototype,"serverResponse",{get:function(){return this.customData.serverResponse},set:function(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=this._baseMessage+"\n"+this.customData.serverResponse:this.message=this._baseMessage},enumerable:!1,configurable:!0}),t}(o["c"]);function f(e){return"storage/"+e}function p(){var e="An unknown error occurred, please check the error payload for server response.";return new h("unknown",e)}function d(e){return new h("object-not-found","Object '"+e+"' does not exist.")}function v(e){return new h("quota-exceeded","Quota for bucket '"+e+"' exceeded, please view quota on https://firebase.google.com/pricing/.")}function _(){var e="User is not authenticated, please authenticate using Firebase Authentication and try again.";return new h("unauthenticated",e)}function g(){return new h("unauthorized-app","This app does not have permission to access Firebase Storage on this project.")}function b(e){return new h("unauthorized","User does not have permission to access '"+e+"'.")}function m(){return new h("retry-limit-exceeded","Max retry time for operation exceeded, please try again.")}function y(){return new h("canceled","User canceled the upload/download.")}function w(e){return new h("invalid-url","Invalid URL '"+e+"'.")}function R(e){return new h("invalid-default-bucket","Invalid default bucket '"+e+"'.")}function O(){return new h("no-default-bucket","No default bucket found. Did you set the '"+u+"' property when initializing the app?")}function k(){return new h("cannot-slice-blob","Cannot slice blob for upload. Please retry the upload.")}function T(){return new h("server-file-wrong-size","Server recorded incorrect upload file size, please retry the upload.")}function S(){return new h("no-download-url","The given file does not have any download URLs.")}function C(e){return new h("invalid-argument",e)}function E(){return new h("app-deleted","The Firebase app was deleted.")}function P(e){return new h("invalid-root-operation","The operation '"+e+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}function I(e,t){return new h("invalid-format","String does not match format '"+e+"': "+t)}function x(e){throw new h("internal-error","Internal error: "+e)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var j={RAW:"raw",BASE64:"base64",BASE64URL:"base64url",DATA_URL:"data_url"},U=function(){function e(e,t){this.data=e,this.contentType=t||null}return e}();function A(e,t){switch(e){case j.RAW:return new U(L(t));case j.BASE64:case j.BASE64URL:return new U(N(e,t));case j.DATA_URL:return new U(D(t),B(t))}throw p()}function L(e){for(var t=[],n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<=127)t.push(r);else if(r<=2047)t.push(192|r>>6,128|63&r);else if(55296===(64512&r)){var i=n<e.length-1&&56320===(64512&e.charCodeAt(n+1));if(i){var o=r,s=e.charCodeAt(++n);r=65536|(1023&o)<<10|1023&s,t.push(240|r>>18,128|r>>12&63,128|r>>6&63,128|63&r)}else t.push(239,191,189)}else 56320===(64512&r)?t.push(239,191,189):t.push(224|r>>12,128|r>>6&63,128|63&r)}return new Uint8Array(t)}function z(e){var t;try{t=decodeURIComponent(e)}catch(n){throw I(j.DATA_URL,"Malformed data URL.")}return L(t)}function N(e,t){switch(e){case j.BASE64:var n=-1!==t.indexOf("-"),r=-1!==t.indexOf("_");if(n||r){var i=n?"-":"_";throw I(e,"Invalid character '"+i+"' found: is it base64url encoded?")}break;case j.BASE64URL:var o=-1!==t.indexOf("+"),s=-1!==t.indexOf("/");if(o||s){i=o?"+":"/";throw I(e,"Invalid character '"+i+"' found: is it base64 encoded?")}t=t.replace(/-/g,"+").replace(/_/g,"/");break}var a;try{a=atob(t)}catch(l){throw I(e,"Invalid character found")}for(var u=new Uint8Array(a.length),c=0;c<a.length;c++)u[c]=a.charCodeAt(c);return u}var H=function(){function e(e){this.base64=!1,this.contentType=null;var t=e.match(/^data:([^,]+)?,/);if(null===t)throw I(j.DATA_URL,"Must be formatted 'data:[<mediatype>][;base64],<data>");var n=t[1]||null;null!=n&&(this.base64=M(n,";base64"),this.contentType=this.base64?n.substring(0,n.length-";base64".length):n),this.rest=e.substring(e.indexOf(",")+1)}return e}();function D(e){var t=new H(e);return t.base64?N(j.BASE64,t.rest):z(t.rest)}function B(e){var t=new H(e);return t.contentType}function M(e,t){var n=e.length>=t.length;return!!n&&e.substring(e.length-t.length)===t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var q,F={STATE_CHANGED:"state_changed"},G={RUNNING:"running",PAUSED:"paused",SUCCESS:"success",CANCELED:"canceled",ERROR:"error"};function W(e){switch(e){case"running":case"pausing":case"canceling":return G.RUNNING;case"paused":return G.PAUSED;case"success":return G.SUCCESS;case"canceled":return G.CANCELED;case"error":return G.ERROR;default:return G.ERROR}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(function(e){e[e["NO_ERROR"]=0]="NO_ERROR",e[e["NETWORK_ERROR"]=1]="NETWORK_ERROR",e[e["ABORT"]=2]="ABORT"})(q||(q={}));
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var X=function(){function e(){var e=this;this.sent_=!1,this.xhr_=new XMLHttpRequest,this.errorCode_=q.NO_ERROR,this.sendPromise_=new Promise((function(t){e.xhr_.addEventListener("abort",(function(){e.errorCode_=q.ABORT,t(e)})),e.xhr_.addEventListener("error",(function(){e.errorCode_=q.NETWORK_ERROR,t(e)})),e.xhr_.addEventListener("load",(function(){t(e)}))}))}return e.prototype.send=function(e,t,n,r){if(this.sent_)throw x("cannot .send() more than once");if(this.sent_=!0,this.xhr_.open(t,e,!0),void 0!==r)for(var i in r)r.hasOwnProperty(i)&&this.xhr_.setRequestHeader(i,r[i].toString());return void 0!==n?this.xhr_.send(n):this.xhr_.send(),this.sendPromise_},e.prototype.getErrorCode=function(){if(!this.sent_)throw x("cannot .getErrorCode() before sending");return this.errorCode_},e.prototype.getStatus=function(){if(!this.sent_)throw x("cannot .getStatus() before sending");try{return this.xhr_.status}catch(e){return-1}},e.prototype.getResponseText=function(){if(!this.sent_)throw x("cannot .getResponseText() before sending");return this.xhr_.responseText},e.prototype.abort=function(){this.xhr_.abort()},e.prototype.getResponseHeader=function(e){return this.xhr_.getResponseHeader(e)},e.prototype.addUploadProgressListener=function(e){null!=this.xhr_.upload&&this.xhr_.upload.addEventListener("progress",e)},e.prototype.removeUploadProgressListener=function(e){null!=this.xhr_.upload&&this.xhr_.upload.removeEventListener("progress",e)},e}(),V=function(){function e(){}return e.prototype.createXhrIo=function(){return new X},e}(),K=function(){function e(e,t){this.bucket=e,this.path_=t}return Object.defineProperty(e.prototype,"path",{get:function(){return this.path_},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"isRoot",{get:function(){return 0===this.path.length},enumerable:!1,configurable:!0}),e.prototype.fullServerUrl=function(){var e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)},e.prototype.bucketOnlyServerUrl=function(){var e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o"},e.makeFromBucketSpec=function(t,n){var r;try{r=e.makeFromUrl(t,n)}catch(i){return new e(t,"")}if(""===r.path)return r;throw R(t)},e.makeFromUrl=function(t,n){var r=null,i="([A-Za-z0-9.\\-_]+)";function o(e){"/"===e.path.charAt(e.path.length-1)&&(e.path_=e.path_.slice(0,-1))}var s="(/(.*))?$",u=new RegExp("^gs://"+i+s,"i"),c={bucket:1,path:3};function l(e){e.path_=decodeURIComponent(e.path)}for(var h="v[A-Za-z0-9_]+",f=n.replace(/[.]/g,"\\."),p="(/([^?#]*).*)?$",d=new RegExp("^https?://"+f+"/"+h+"/b/"+i+"/o"+p,"i"),v={bucket:1,path:3},_=n===a?"(?:storage.googleapis.com|storage.cloud.google.com)":n,g="([^?#]*)",b=new RegExp("^https?://"+_+"/"+i+"/"+g,"i"),m={bucket:1,path:2},y=[{regex:u,indices:c,postModify:o},{regex:d,indices:v,postModify:l},{regex:b,indices:m,postModify:l}],R=0;R<y.length;R++){var O=y[R],k=O.regex.exec(t);if(k){var T=k[O.indices.bucket],S=k[O.indices.path];S||(S=""),r=new e(T,S),O.postModify(r);break}}if(null==r)throw w(t);return r},e}(),J=function(){function e(e){this.promise_=Promise.reject(e)}return e.prototype.getPromise=function(){return this.promise_},e.prototype.cancel=function(e){},e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(e,t,n){var r=1,o=null,s=!1,a=0;function u(){return 2===a}var c=!1;function l(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n];c||(c=!0,t.apply(null,e))}function h(t){o=setTimeout((function(){o=null,e(f,u())}),t)}function f(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];if(!c)if(e)l.call.apply(l,Object(i["f"])([null,e],t));else{var o,f=u()||s;if(f)l.call.apply(l,Object(i["f"])([null,e],t));else r<64&&(r*=2),1===a?(a=2,o=0):o=1e3*(r+Math.random()),h(o)}}var p=!1;function d(e){p||(p=!0,c||(null!==o?(e||(a=2),clearTimeout(o),h(0)):e||(a=1)))}return h(0),setTimeout((function(){s=!0,d(!0)}),n),d}function $(e){e(!1)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Y(e){return void 0!==e}function Q(e){return"function"===typeof e}function ee(e){return"object"===typeof e&&!Array.isArray(e)}function te(e){return"string"===typeof e||e instanceof String}function ne(e){return re()&&e instanceof Blob}function re(){return"undefined"!==typeof Blob}function ie(e,t,n,r){if(r<t)throw C("Invalid value for '"+e+"'. Expected "+t+" or greater.");if(r>n)throw C("Invalid value for '"+e+"'. Expected "+n+" or less.")}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oe(e,t){var n=t.match(/^(\w+):\/\/.+/),r=null===n||void 0===n?void 0:n[1],i=t;return null==r&&(i="https://"+t),i+"/v0"+e}function se(e){var t=encodeURIComponent,n="?";for(var r in e)if(e.hasOwnProperty(r)){var i=t(r)+"="+t(e[r]);n=n+i+"&"}return n=n.slice(0,-1),n}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ae=function(){function e(e,t,n,r,i,o,s,a,u,c,l){var h=this;this.pendingXhr_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.url_=e,this.method_=t,this.headers_=n,this.body_=r,this.successCodes_=i.slice(),this.additionalRetryCodes_=o.slice(),this.callback_=s,this.errorCallback_=a,this.progressCallback_=c,this.timeout_=u,this.pool_=l,this.promise_=new Promise((function(e,t){h.resolve_=e,h.reject_=t,h.start_()}))}return e.prototype.start_=function(){var e=this;function t(t,n){if(n)t(!1,new ue(!1,null,!0));else{var r=e.pool_.createXhrIo();e.pendingXhr_=r,null!==e.progressCallback_&&r.addUploadProgressListener(i),r.send(e.url_,e.method_,e.body_,e.headers_).then((function(n){null!==e.progressCallback_&&n.removeUploadProgressListener(i),e.pendingXhr_=null,n=n;var r=n.getErrorCode()===q.NO_ERROR,o=n.getStatus();if(r&&!e.isRetryStatusCode_(o)){var s=-1!==e.successCodes_.indexOf(o);t(!0,new ue(s,n))}else{var a=n.getErrorCode()===q.ABORT;t(!1,new ue(!1,null,a))}}))}function i(t){var n=t.loaded,r=t.lengthComputable?t.total:-1;null!==e.progressCallback_&&e.progressCallback_(n,r)}}function n(t,n){var r=e.resolve_,i=e.reject_,o=n.xhr;if(n.wasSuccessCode)try{var s=e.callback_(o,o.getResponseText());Y(s)?r(s):r()}catch(u){i(u)}else if(null!==o){var a=p();a.serverResponse=o.getResponseText(),e.errorCallback_?i(e.errorCallback_(o,a)):i(a)}else if(n.canceled){a=e.appDelete_?E():y();i(a)}else{a=m();i(a)}}this.canceled_?n(!1,new ue(!1,null,!0)):this.backoffId_=Z(t,n,this.timeout_)},e.prototype.getPromise=function(){return this.promise_},e.prototype.cancel=function(e){this.canceled_=!0,this.appDelete_=e||!1,null!==this.backoffId_&&$(this.backoffId_),null!==this.pendingXhr_&&this.pendingXhr_.abort()},e.prototype.isRetryStatusCode_=function(e){var t=e>=500&&e<600,n=[408,429],r=-1!==n.indexOf(e),i=-1!==this.additionalRetryCodes_.indexOf(e);return t||r||i},e}(),ue=function(){function e(e,t,n){this.wasSuccessCode=e,this.xhr=t,this.canceled=!!n}return e}();function ce(e,t){null!==t&&t.length>0&&(e["Authorization"]="Firebase "+t)}function le(e,t){e["X-Firebase-Storage-Version"]="webjs/"+(null!==t&&void 0!==t?t:"AppManager")}function he(e,t){t&&(e["X-Firebase-GMPID"]=t)}function fe(e,t){null!==t&&(e["X-Firebase-AppCheck"]=t)}function pe(e,t,n,r,i,o){var s=se(e.urlParams),a=e.url+s,u=Object.assign({},e.headers);return he(u,t),ce(u,n),le(u,o),fe(u,r),new ae(a,e.method,u,e.body,e.successCodes,e.additionalRetryCodes,e.handler,e.errorHandler,e.timeout,e.progressCallback,i)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function de(){return"undefined"!==typeof BlobBuilder?BlobBuilder:"undefined"!==typeof WebKitBlobBuilder?WebKitBlobBuilder:void 0}function ve(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];var n=de();if(void 0!==n){for(var r=new n,i=0;i<e.length;i++)r.append(e[i]);return r.getBlob()}if(re())return new Blob(e);throw new h("unsupported-environment","This browser doesn't seem to support creating Blobs")}function _e(e,t,n){return e.webkitSlice?e.webkitSlice(t,n):e.mozSlice?e.mozSlice(t,n):e.slice?e.slice(t,n):null}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ge=function(){function e(e,t){var n=0,r="";ne(e)?(this.data_=e,n=e.size,r=e.type):e instanceof ArrayBuffer?(t?this.data_=new Uint8Array(e):(this.data_=new Uint8Array(e.byteLength),this.data_.set(new Uint8Array(e))),n=this.data_.length):e instanceof Uint8Array&&(t?this.data_=e:(this.data_=new Uint8Array(e.length),this.data_.set(e)),n=e.length),this.size_=n,this.type_=r}return e.prototype.size=function(){return this.size_},e.prototype.type=function(){return this.type_},e.prototype.slice=function(t,n){if(ne(this.data_)){var r=this.data_,i=_e(r,t,n);return null===i?null:new e(i)}var o=new Uint8Array(this.data_.buffer,t,n-t);return new e(o,!0)},e.getBlob=function(){for(var t=[],n=0;n<arguments.length;n++)t[n]=arguments[n];if(re()){var r=t.map((function(t){return t instanceof e?t.data_:t}));return new e(ve.apply(null,r))}var i=t.map((function(e){return te(e)?A(j.RAW,e).data:e.data_})),o=0;i.forEach((function(e){o+=e.byteLength}));var s=new Uint8Array(o),a=0;return i.forEach((function(e){for(var t=0;t<e.length;t++)s[a++]=e[t]})),new e(s,!0)},e.prototype.uploadData=function(){return this.data_},e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function be(e){var t;try{t=JSON.parse(e)}catch(n){return null}return ee(t)?t:null}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function me(e){if(0===e.length)return null;var t=e.lastIndexOf("/");if(-1===t)return"";var n=e.slice(0,t);return n}function ye(e,t){var n=t.split("/").filter((function(e){return e.length>0})).join("/");return 0===e.length?n:e+"/"+n}function we(e){var t=e.lastIndexOf("/",e.length-2);return-1===t?e:e.slice(t+1)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Re(e,t){return t}var Oe=function(){function e(e,t,n,r){this.server=e,this.local=t||e,this.writable=!!n,this.xform=r||Re}return e}(),ke=null;function Te(e){return!te(e)||e.length<2?e:we(e)}function Se(){if(ke)return ke;var e=[];function t(e,t){return Te(t)}e.push(new Oe("bucket")),e.push(new Oe("generation")),e.push(new Oe("metageneration")),e.push(new Oe("name","fullPath",!0));var n=new Oe("name");function r(e,t){return void 0!==t?Number(t):t}n.xform=t,e.push(n);var i=new Oe("size");return i.xform=r,e.push(i),e.push(new Oe("timeCreated")),e.push(new Oe("updated")),e.push(new Oe("md5Hash",null,!0)),e.push(new Oe("cacheControl",null,!0)),e.push(new Oe("contentDisposition",null,!0)),e.push(new Oe("contentEncoding",null,!0)),e.push(new Oe("contentLanguage",null,!0)),e.push(new Oe("contentType",null,!0)),e.push(new Oe("metadata","customMetadata",!0)),ke=e,ke}function Ce(e,t){function n(){var n=e["bucket"],r=e["fullPath"],i=new K(n,r);return t._makeStorageReference(i)}Object.defineProperty(e,"ref",{get:n})}function Ee(e,t,n){for(var r={type:"file"},i=n.length,o=0;o<i;o++){var s=n[o];r[s.local]=s.xform(r,t[s.server])}return Ce(r,e),r}function Pe(e,t,n){var r=be(t);if(null===r)return null;var i=r;return Ee(e,i,n)}function Ie(e,t,n){var r=be(t);if(null===r)return null;if(!te(r["downloadTokens"]))return null;var i=r["downloadTokens"];if(0===i.length)return null;var o=encodeURIComponent,s=i.split(","),a=s.map((function(t){var r=e["bucket"],i=e["fullPath"],s="/b/"+o(r)+"/o/"+o(i),a=oe(s,n),u=se({alt:"media",token:t});return a+u}));return a[0]}function xe(e,t){for(var n={},r=t.length,i=0;i<r;i++){var o=t[i];o.writable&&(n[o.server]=e[o.local])}return JSON.stringify(n)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var je="prefixes",Ue="items";function Ae(e,t,n){var r={prefixes:[],items:[],nextPageToken:n["nextPageToken"]};if(n[je])for(var i=0,o=n[je];i<o.length;i++){var s=o[i],a=s.replace(/\/$/,""),u=e._makeStorageReference(new K(t,a));r.prefixes.push(u)}if(n[Ue])for(var c=0,l=n[Ue];c<l.length;c++){var h=l[c];u=e._makeStorageReference(new K(t,h["name"]));r.items.push(u)}return r}function Le(e,t,n){var r=be(n);if(null===r)return null;var i=r;return Ae(e,t,i)}var ze=function(){function e(e,t,n,r){this.url=e,this.method=t,this.handler=n,this.timeout=r,this.urlParams={},this.headers={},this.body=null,this.errorHandler=null,this.progressCallback=null,this.successCodes=[200],this.additionalRetryCodes=[]}return e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ne(e){if(!e)throw p()}function He(e,t){function n(n,r){var i=Pe(e,r,t);return Ne(null!==i),i}return n}function De(e,t){function n(n,r){var i=Le(e,t,r);return Ne(null!==i),i}return n}function Be(e,t){function n(n,r){var i=Pe(e,r,t);return Ne(null!==i),Ie(i,r,e.host)}return n}function Me(e){function t(t,n){var r;return r=401===t.getStatus()?t.getResponseText().includes("Firebase App Check token is invalid")?g():_():402===t.getStatus()?v(e.bucket):403===t.getStatus()?b(e.path):n,r.serverResponse=n.serverResponse,r}return t}function qe(e){var t=Me(e);function n(n,r){var i=t(n,r);return 404===n.getStatus()&&(i=d(e.path)),i.serverResponse=r.serverResponse,i}return n}function Fe(e,t,n){var r=t.fullServerUrl(),i=oe(r,e.host),o="GET",s=e.maxOperationRetryTime,a=new ze(i,o,He(e,n),s);return a.errorHandler=qe(t),a}function Ge(e,t,n,r,i){var o={};t.isRoot?o["prefix"]="":o["prefix"]=t.path+"/",n&&n.length>0&&(o["delimiter"]=n),r&&(o["pageToken"]=r),i&&(o["maxResults"]=i);var s=t.bucketOnlyServerUrl(),a=oe(s,e.host),u="GET",c=e.maxOperationRetryTime,l=new ze(a,u,De(e,t.bucket),c);return l.urlParams=o,l.errorHandler=Me(t),l}function We(e,t,n){var r=t.fullServerUrl(),i=oe(r,e.host),o="GET",s=e.maxOperationRetryTime,a=new ze(i,o,Be(e,n),s);return a.errorHandler=qe(t),a}function Xe(e,t,n,r){var i=t.fullServerUrl(),o=oe(i,e.host),s="PATCH",a=xe(n,r),u={"Content-Type":"application/json; charset=utf-8"},c=e.maxOperationRetryTime,l=new ze(o,s,He(e,r),c);return l.headers=u,l.body=a,l.errorHandler=qe(t),l}function Ve(e,t){var n=t.fullServerUrl(),r=oe(n,e.host),i="DELETE",o=e.maxOperationRetryTime;function s(e,t){}var a=new ze(r,i,s,o);return a.successCodes=[200,204],a.errorHandler=qe(t),a}function Ke(e,t){return e&&e["contentType"]||t&&t.type()||"application/octet-stream"}function Je(e,t,n){var r=Object.assign({},n);return r["fullPath"]=e.path,r["size"]=t.size(),r["contentType"]||(r["contentType"]=Ke(null,t)),r}function Ze(e,t,n,r,i){var o=t.bucketOnlyServerUrl(),s={"X-Goog-Upload-Protocol":"multipart"};function a(){for(var e="",t=0;t<2;t++)e+=Math.random().toString().slice(2);return e}var u=a();s["Content-Type"]="multipart/related; boundary="+u;var c=Je(t,r,i),l=xe(c,n),h="--"+u+"\r\nContent-Type: application/json; charset=utf-8\r\n\r\n"+l+"\r\n--"+u+"\r\nContent-Type: "+c["contentType"]+"\r\n\r\n",f="\r\n--"+u+"--",p=ge.getBlob(h,r,f);if(null===p)throw k();var d={name:c["fullPath"]},v=oe(o,e.host),_="POST",g=e.maxUploadRetryTime,b=new ze(v,_,He(e,n),g);return b.urlParams=d,b.headers=s,b.body=p.uploadData(),b.errorHandler=Me(t),b}var $e=function(){function e(e,t,n,r){this.current=e,this.total=t,this.finalized=!!n,this.metadata=r||null}return e}();function Ye(e,t){var n=null;try{n=e.getResponseHeader("X-Goog-Upload-Status")}catch(i){Ne(!1)}var r=t||["active"];return Ne(!!n&&-1!==r.indexOf(n)),n}function Qe(e,t,n,r,i){var o=t.bucketOnlyServerUrl(),s=Je(t,r,i),a={name:s["fullPath"]},u=oe(o,e.host),c="POST",l={"X-Goog-Upload-Protocol":"resumable","X-Goog-Upload-Command":"start","X-Goog-Upload-Header-Content-Length":r.size(),"X-Goog-Upload-Header-Content-Type":s["contentType"],"Content-Type":"application/json; charset=utf-8"},h=xe(s,n),f=e.maxUploadRetryTime;function p(e){var t;Ye(e);try{t=e.getResponseHeader("X-Goog-Upload-URL")}catch(n){Ne(!1)}return Ne(te(t)),t}var d=new ze(u,c,p,f);return d.urlParams=a,d.headers=l,d.body=h,d.errorHandler=Me(t),d}function et(e,t,n,r){var i={"X-Goog-Upload-Command":"query"};function o(e){var t=Ye(e,["active","final"]),n=null;try{n=e.getResponseHeader("X-Goog-Upload-Size-Received")}catch(o){Ne(!1)}n||Ne(!1);var i=Number(n);return Ne(!isNaN(i)),new $e(i,r.size(),"final"===t)}var s="POST",a=e.maxUploadRetryTime,u=new ze(n,s,o,a);return u.headers=i,u.errorHandler=Me(t),u}var tt=262144;function nt(e,t,n,r,i,o,s,a){var u=new $e(0,0);if(s?(u.current=s.current,u.total=s.total):(u.current=0,u.total=r.size()),r.size()!==u.total)throw T();var c=u.total-u.current,l=c;i>0&&(l=Math.min(l,i));var h=u.current,f=h+l,p=l===c?"upload, finalize":"upload",d={"X-Goog-Upload-Command":p,"X-Goog-Upload-Offset":u.current},v=r.slice(h,f);if(null===v)throw k();function _(e,n){var i,s=Ye(e,["active","final"]),a=u.current+l,c=r.size();return i="final"===s?He(t,o)(e,n):null,new $e(a,c,"final"===s,i)}var g="POST",b=t.maxUploadRetryTime,m=new ze(n,g,_,b);return m.headers=d,m.body=v.uploadData(),m.progressCallback=a||null,m.errorHandler=Me(e),m}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var rt=function(){function e(e,t,n){var r=Q(e)||null!=t||null!=n;if(r)this.next=e,this.error=t,this.complete=n;else{var i=e;this.next=i.next,this.error=i.error,this.complete=i.complete}}return e}();
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function it(e){return function(){for(var t=[],n=0;n<arguments.length;n++)t[n]=arguments[n];Promise.resolve().then((function(){return e.apply(void 0,t)}))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ot=function(){function e(e,t,n){var r=this;void 0===n&&(n=null),this._transferred=0,this._needToFetchStatus=!1,this._needToFetchMetadata=!1,this._observers=[],this._error=void 0,this._uploadUrl=void 0,this._request=void 0,this._chunkMultiplier=1,this._resolve=void 0,this._reject=void 0,this._ref=e,this._blob=t,this._metadata=n,this._mappings=Se(),this._resumable=this._shouldDoResumable(this._blob),this._state="running",this._errorHandler=function(e){r._request=void 0,r._chunkMultiplier=1,e._codeEquals("canceled")?(r._needToFetchStatus=!0,r.completeTransitions_()):(r._error=e,r._transition("error"))},this._metadataErrorHandler=function(e){r._request=void 0,e._codeEquals("canceled")?r.completeTransitions_():(r._error=e,r._transition("error"))},this._promise=new Promise((function(e,t){r._resolve=e,r._reject=t,r._start()})),this._promise.then(null,(function(){}))}return e.prototype._makeProgressCallback=function(){var e=this,t=this._transferred;return function(n){return e._updateProgress(t+n)}},e.prototype._shouldDoResumable=function(e){return e.size()>262144},e.prototype._start=function(){"running"===this._state&&void 0===this._request&&(this._resumable?void 0===this._uploadUrl?this._createResumable():this._needToFetchStatus?this._fetchStatus():this._needToFetchMetadata?this._fetchMetadata():this._continueUpload():this._oneShotUpload())},e.prototype._resolveToken=function(e){var t=this;Promise.all([this._ref.storage._getAuthToken(),this._ref.storage._getAppCheckToken()]).then((function(n){var r=n[0],i=n[1];switch(t._state){case"running":e(r,i);break;case"canceling":t._transition("canceled");break;case"pausing":t._transition("paused");break}}))},e.prototype._createResumable=function(){var e=this;this._resolveToken((function(t,n){var r=Qe(e._ref.storage,e._ref._location,e._mappings,e._blob,e._metadata),i=e._ref.storage._makeRequest(r,t,n);e._request=i,i.getPromise().then((function(t){e._request=void 0,e._uploadUrl=t,e._needToFetchStatus=!1,e.completeTransitions_()}),e._errorHandler)}))},e.prototype._fetchStatus=function(){var e=this,t=this._uploadUrl;this._resolveToken((function(n,r){var i=et(e._ref.storage,e._ref._location,t,e._blob),o=e._ref.storage._makeRequest(i,n,r);e._request=o,o.getPromise().then((function(t){t=t,e._request=void 0,e._updateProgress(t.current),e._needToFetchStatus=!1,t.finalized&&(e._needToFetchMetadata=!0),e.completeTransitions_()}),e._errorHandler)}))},e.prototype._continueUpload=function(){var e=this,t=tt*this._chunkMultiplier,n=new $e(this._transferred,this._blob.size()),r=this._uploadUrl;this._resolveToken((function(i,o){var s;try{s=nt(e._ref._location,e._ref.storage,r,e._blob,t,e._mappings,n,e._makeProgressCallback())}catch(u){return e._error=u,void e._transition("error")}var a=e._ref.storage._makeRequest(s,i,o);e._request=a,a.getPromise().then((function(t){e._increaseMultiplier(),e._request=void 0,e._updateProgress(t.current),t.finalized?(e._metadata=t.metadata,e._transition("success")):e.completeTransitions_()}),e._errorHandler)}))},e.prototype._increaseMultiplier=function(){var e=tt*this._chunkMultiplier;e<33554432&&(this._chunkMultiplier*=2)},e.prototype._fetchMetadata=function(){var e=this;this._resolveToken((function(t,n){var r=Fe(e._ref.storage,e._ref._location,e._mappings),i=e._ref.storage._makeRequest(r,t,n);e._request=i,i.getPromise().then((function(t){e._request=void 0,e._metadata=t,e._transition("success")}),e._metadataErrorHandler)}))},e.prototype._oneShotUpload=function(){var e=this;this._resolveToken((function(t,n){var r=Ze(e._ref.storage,e._ref._location,e._mappings,e._blob,e._metadata),i=e._ref.storage._makeRequest(r,t,n);e._request=i,i.getPromise().then((function(t){e._request=void 0,e._metadata=t,e._updateProgress(e._blob.size()),e._transition("success")}),e._errorHandler)}))},e.prototype._updateProgress=function(e){var t=this._transferred;this._transferred=e,this._transferred!==t&&this._notifyObservers()},e.prototype._transition=function(e){if(this._state!==e)switch(e){case"canceling":this._state=e,void 0!==this._request&&this._request.cancel();break;case"pausing":this._state=e,void 0!==this._request&&this._request.cancel();break;case"running":var t="paused"===this._state;this._state=e,t&&(this._notifyObservers(),this._start());break;case"paused":this._state=e,this._notifyObservers();break;case"canceled":this._error=y(),this._state=e,this._notifyObservers();break;case"error":this._state=e,this._notifyObservers();break;case"success":this._state=e,this._notifyObservers();break}},e.prototype.completeTransitions_=function(){switch(this._state){case"pausing":this._transition("paused");break;case"canceling":this._transition("canceled");break;case"running":this._start();break}},Object.defineProperty(e.prototype,"snapshot",{get:function(){var e=W(this._state);return{bytesTransferred:this._transferred,totalBytes:this._blob.size(),state:e,metadata:this._metadata,task:this,ref:this._ref}},enumerable:!1,configurable:!0}),e.prototype.on=function(e,t,n,r){var i=this,o=new rt(t,n,r);return this._addObserver(o),function(){i._removeObserver(o)}},e.prototype.then=function(e,t){return this._promise.then(e,t)},e.prototype.catch=function(e){return this.then(null,e)},e.prototype._addObserver=function(e){this._observers.push(e),this._notifyObserver(e)},e.prototype._removeObserver=function(e){var t=this._observers.indexOf(e);-1!==t&&this._observers.splice(t,1)},e.prototype._notifyObservers=function(){var e=this;this._finishPromise();var t=this._observers.slice();t.forEach((function(t){e._notifyObserver(t)}))},e.prototype._finishPromise=function(){if(void 0!==this._resolve){var e=!0;switch(W(this._state)){case G.SUCCESS:it(this._resolve.bind(null,this.snapshot))();break;case G.CANCELED:case G.ERROR:var t=this._reject;it(t.bind(null,this._error))();break;default:e=!1;break}e&&(this._resolve=void 0,this._reject=void 0)}},e.prototype._notifyObserver=function(e){var t=W(this._state);switch(t){case G.RUNNING:case G.PAUSED:e.next&&it(e.next.bind(e,this.snapshot))();break;case G.SUCCESS:e.complete&&it(e.complete.bind(e))();break;case G.CANCELED:case G.ERROR:e.error&&it(e.error.bind(e,this._error))();break;default:e.error&&it(e.error.bind(e,this._error))()}},e.prototype.resume=function(){var e="paused"===this._state||"pausing"===this._state;return e&&this._transition("running"),e},e.prototype.pause=function(){var e="running"===this._state;return e&&this._transition("pausing"),e},e.prototype.cancel=function(){var e="running"===this._state||"pausing"===this._state;return e&&this._transition("canceling"),e},e}(),st=function(){function e(e,t){this._service=e,this._location=t instanceof K?t:K.makeFromUrl(t,e.host)}return e.prototype.toString=function(){return"gs://"+this._location.bucket+"/"+this._location.path},e.prototype._newRef=function(t,n){return new e(t,n)},Object.defineProperty(e.prototype,"root",{get:function(){var e=new K(this._location.bucket,"");return this._newRef(this._service,e)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"bucket",{get:function(){return this._location.bucket},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"fullPath",{get:function(){return this._location.path},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"name",{get:function(){return we(this._location.path)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"storage",{get:function(){return this._service},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"parent",{get:function(){var t=me(this._location.path);if(null===t)return null;var n=new K(this._location.bucket,t);return new e(this._service,n)},enumerable:!1,configurable:!0}),e.prototype._throwIfRoot=function(e){if(""===this._location.path)throw P(e)},e}();
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function at(e,t,n){return e._throwIfRoot("uploadBytesResumable"),new ot(e,new ge(t),n)}function ut(e){var t={prefixes:[],items:[]};return ct(e,t).then((function(){return t}))}function ct(e,t,n){return Object(i["b"])(this,void 0,void 0,(function(){var r,o,s,a;return Object(i["d"])(this,(function(i){switch(i.label){case 0:return r={pageToken:n},[4,lt(e,r)];case 1:return o=i.sent(),(s=t.prefixes).push.apply(s,o.prefixes),(a=t.items).push.apply(a,o.items),null==o.nextPageToken?[3,3]:[4,ct(e,t,o.nextPageToken)];case 2:i.sent(),i.label=3;case 3:return[2]}}))}))}function lt(e,t){return Object(i["b"])(this,void 0,void 0,(function(){var n,r;return Object(i["d"])(this,(function(i){switch(i.label){case 0:return null!=t&&"number"===typeof t.maxResults&&ie("options.maxResults",1,1e3,t.maxResults),n=t||{},r=Ge(e.storage,e._location,"/",n.pageToken,n.maxResults),[4,e.storage.makeRequestWithTokens(r)];case 1:return[2,i.sent().getPromise()]}}))}))}function ht(e){return Object(i["b"])(this,void 0,void 0,(function(){var t;return Object(i["d"])(this,(function(n){switch(n.label){case 0:return e._throwIfRoot("getMetadata"),t=Fe(e.storage,e._location,Se()),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,n.sent().getPromise()]}}))}))}function ft(e,t){return Object(i["b"])(this,void 0,void 0,(function(){var n;return Object(i["d"])(this,(function(r){switch(r.label){case 0:return e._throwIfRoot("updateMetadata"),n=Xe(e.storage,e._location,t,Se()),[4,e.storage.makeRequestWithTokens(n)];case 1:return[2,r.sent().getPromise()]}}))}))}function pt(e){return Object(i["b"])(this,void 0,void 0,(function(){var t;return Object(i["d"])(this,(function(n){switch(n.label){case 0:return e._throwIfRoot("getDownloadURL"),t=We(e.storage,e._location,Se()),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,n.sent().getPromise().then((function(e){if(null===e)throw S();return e}))]}}))}))}function dt(e){return Object(i["b"])(this,void 0,void 0,(function(){var t;return Object(i["d"])(this,(function(n){switch(n.label){case 0:return e._throwIfRoot("deleteObject"),t=Ve(e.storage,e._location),[4,e.storage.makeRequestWithTokens(t)];case 1:return[2,n.sent().getPromise()]}}))}))}function vt(e,t){var n=ye(e._location.path,t),r=new K(e._location.bucket,n);return new st(e.storage,r)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _t(e){return/^[A-Za-z]+:\/\//.test(e)}function gt(e,t){return new st(e,t)}function bt(e,t){if(e instanceof Rt){var n=e;if(null==n._bucket)throw O();var r=new st(n,n._bucket);return null!=t?bt(r,t):r}if(void 0!==t){if(t.includes(".."))throw C('`path` param cannot contain ".."');return vt(e,t)}return e}function mt(e,t){if(t&&_t(t)){if(e instanceof Rt)return gt(e,t);throw C("To use ref(service, url), the first argument must be a Storage instance.")}return bt(e,t)}function yt(e,t){var n=null===t||void 0===t?void 0:t[u];return null==n?null:K.makeFromBucketSpec(n,e)}function wt(e,t,n){e.host="http://"+t+":"+n}var Rt=function(){function e(e,t,n,r,i,o){this.app=e,this._authProvider=t,this._appCheckProvider=n,this._pool=r,this._url=i,this._firebaseVersion=o,this._bucket=null,this._host=a,this._appId=null,this._deleted=!1,this._maxOperationRetryTime=c,this._maxUploadRetryTime=l,this._requests=new Set,this._bucket=null!=i?K.makeFromBucketSpec(i,this._host):yt(this._host,this.app.options)}return Object.defineProperty(e.prototype,"host",{get:function(){return this._host},set:function(e){this._host=e,null!=this._url?this._bucket=K.makeFromBucketSpec(this._url,e):this._bucket=yt(e,this.app.options)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxUploadRetryTime",{get:function(){return this._maxUploadRetryTime},set:function(e){ie("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxOperationRetryTime",{get:function(){return this._maxOperationRetryTime},set:function(e){ie("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e},enumerable:!1,configurable:!0}),e.prototype._getAuthToken=function(){return Object(i["b"])(this,void 0,void 0,(function(){var e,t;return Object(i["d"])(this,(function(n){switch(n.label){case 0:return e=this._authProvider.getImmediate({optional:!0}),e?[4,e.getToken()]:[3,2];case 1:if(t=n.sent(),null!==t)return[2,t.accessToken];n.label=2;case 2:return[2,null]}}))}))},e.prototype._getAppCheckToken=function(){return Object(i["b"])(this,void 0,void 0,(function(){var e,t;return Object(i["d"])(this,(function(n){switch(n.label){case 0:return e=this._appCheckProvider.getImmediate({optional:!0}),e?[4,e.getToken()]:[3,2];case 1:return t=n.sent(),[2,t.token];case 2:return[2,null]}}))}))},e.prototype._delete=function(){return this._deleted=!0,this._requests.forEach((function(e){return e.cancel()})),this._requests.clear(),Promise.resolve()},e.prototype._makeStorageReference=function(e){return new st(this,e)},e.prototype._makeRequest=function(e,t,n){var r=this;if(this._deleted)return new J(E());var i=pe(e,this._appId,t,n,this._pool,this._firebaseVersion);return this._requests.add(i),i.getPromise().then((function(){return r._requests.delete(i)}),(function(){return r._requests.delete(i)})),i},e.prototype.makeRequestWithTokens=function(e){return Object(i["b"])(this,void 0,void 0,(function(){var t,n,r;return Object(i["d"])(this,(function(i){switch(i.label){case 0:return[4,Promise.all([this._getAuthToken(),this._getAppCheckToken()])];case 1:return t=i.sent(),n=t[0],r=t[1],[2,this._makeRequest(e,n,r)]}}))}))},e}();
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ot(e,t,n){return e=Object(o["h"])(e),at(e,t,n)}function kt(e){return e=Object(o["h"])(e),ht(e)}function Tt(e,t){return e=Object(o["h"])(e),ft(e,t)}function St(e,t){return e=Object(o["h"])(e),lt(e,t)}function Ct(e){return e=Object(o["h"])(e),ut(e)}function Et(e){return e=Object(o["h"])(e),pt(e)}function Pt(e){return e=Object(o["h"])(e),dt(e)}function It(e,t){return e=Object(o["h"])(e),mt(e,t)}function xt(e,t){return vt(e,t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var jt=function(){function e(e,t,n){this._delegate=e,this.task=t,this.ref=n}return Object.defineProperty(e.prototype,"bytesTransferred",{get:function(){return this._delegate.bytesTransferred},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"metadata",{get:function(){return this._delegate.metadata},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"state",{get:function(){return this._delegate.state},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"totalBytes",{get:function(){return this._delegate.totalBytes},enumerable:!1,configurable:!0}),e}(),Ut=function(){function e(e,t){this._delegate=e,this._ref=t,this.cancel=this._delegate.cancel.bind(this._delegate),this.catch=this._delegate.catch.bind(this._delegate),this.pause=this._delegate.pause.bind(this._delegate),this.resume=this._delegate.resume.bind(this._delegate)}return Object.defineProperty(e.prototype,"snapshot",{get:function(){return new jt(this._delegate.snapshot,this,this._ref)},enumerable:!1,configurable:!0}),e.prototype.then=function(e,t){var n=this;return this._delegate.then((function(t){if(e)return e(new jt(t,n,n._ref))}),t)},e.prototype.on=function(e,t,n,r){var i=this,o=void 0;return t&&(o="function"===typeof t?function(e){return t(new jt(e,i,i._ref))}:{next:t.next?function(e){return t.next(new jt(e,i,i._ref))}:void 0,complete:t.complete||void 0,error:t.error||void 0}),this._delegate.on(e,o,n||void 0,r||void 0)},e}(),At=function(){function e(e,t){this._delegate=e,this._service=t}return Object.defineProperty(e.prototype,"prefixes",{get:function(){var e=this;return this._delegate.prefixes.map((function(t){return new Lt(t,e._service)}))},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"items",{get:function(){var e=this;return this._delegate.items.map((function(t){return new Lt(t,e._service)}))},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"nextPageToken",{get:function(){return this._delegate.nextPageToken||null},enumerable:!1,configurable:!0}),e}(),Lt=function(){function e(e,t){this._delegate=e,this.storage=t}return Object.defineProperty(e.prototype,"name",{get:function(){return this._delegate.name},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"bucket",{get:function(){return this._delegate.bucket},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"fullPath",{get:function(){return this._delegate.fullPath},enumerable:!1,configurable:!0}),e.prototype.toString=function(){return this._delegate.toString()},e.prototype.child=function(t){var n=xt(this._delegate,t);return new e(n,this.storage)},Object.defineProperty(e.prototype,"root",{get:function(){return new e(this._delegate.root,this.storage)},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"parent",{get:function(){var t=this._delegate.parent;return null==t?null:new e(t,this.storage)},enumerable:!1,configurable:!0}),e.prototype.put=function(e,t){return this._throwIfRoot("put"),new Ut(Ot(this._delegate,e,t),this)},e.prototype.putString=function(e,t,n){void 0===t&&(t=j.RAW),this._throwIfRoot("putString");var r=A(t,e),o=Object(i["a"])({},n);return null==o["contentType"]&&null!=r.contentType&&(o["contentType"]=r.contentType),new Ut(new ot(this._delegate,new ge(r.data,!0),o),this)},e.prototype.listAll=function(){var e=this;return Ct(this._delegate).then((function(t){return new At(t,e.storage)}))},e.prototype.list=function(e){var t=this;return St(this._delegate,e||void 0).then((function(e){return new At(e,t.storage)}))},e.prototype.getMetadata=function(){return kt(this._delegate)},e.prototype.updateMetadata=function(e){return Tt(this._delegate,e)},e.prototype.getDownloadURL=function(){return Et(this._delegate)},e.prototype.delete=function(){return this._throwIfRoot("delete"),Pt(this._delegate)},e.prototype._throwIfRoot=function(e){if(""===this._delegate._location.path)throw P(e)},e}(),zt=function(){function e(e,t){var n=this;this.app=e,this._delegate=t,this.INTERNAL={delete:function(){return n._delegate._delete()}}}return Object.defineProperty(e.prototype,"maxOperationRetryTime",{get:function(){return this._delegate.maxOperationRetryTime},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"maxUploadRetryTime",{get:function(){return this._delegate.maxUploadRetryTime},enumerable:!1,configurable:!0}),e.prototype.ref=function(e){if(_t(e))throw C("ref() expected a child path but got a URL, use refFromURL instead.");return new Lt(It(this._delegate,e),this)},e.prototype.refFromURL=function(e){if(!_t(e))throw C("refFromURL() expected a full URL but got a child path, use ref() instead.");try{K.makeFromUrl(e,this._delegate.host)}catch(t){throw C("refFromUrl() expected a valid full URL but got an invalid one.")}return new Lt(It(this._delegate,e),this)},e.prototype.setMaxUploadRetryTime=function(e){this._delegate.maxUploadRetryTime=e},e.prototype.setMaxOperationRetryTime=function(e){this._delegate.maxOperationRetryTime=e},e.prototype.useEmulator=function(e,t){wt(this._delegate,e,t)},e}(),Nt="@firebase/storage",Ht="0.5.5",Dt="storage";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bt(e,t){var n=t.instanceIdentifier,i=e.getProvider("app").getImmediate(),o=e.getProvider("auth-internal"),s=e.getProvider("app-check-internal"),a=new zt(i,new Rt(i,o,s,new V,n,r["a"].SDK_VERSION));return a}function Mt(e){var t={TaskState:G,TaskEvent:F,StringFormat:j,Storage:Rt,Reference:Lt};e.INTERNAL.registerComponent(new s["a"](Dt,Bt,"PUBLIC").setServiceProps(t).setMultipleInstances(!0)),e.registerVersion(Nt,Ht)}Mt(r["a"])},5363:function(e,t,n){},a8e9:function(e,t,n){"use strict";(function(e){n.d(t,"a",(function(){return c})),n.d(t,"b",(function(){return d})),n.d(t,"c",(function(){return p})),n.d(t,"d",(function(){return g})),n.d(t,"e",(function(){return b})),n.d(t,"f",(function(){return s})),n.d(t,"g",(function(){return a})),n.d(t,"h",(function(){return R})),n.d(t,"i",(function(){return h})),n.d(t,"j",(function(){return l}));var r=n("9ab4"),i=function(e){for(var t=[],n=0,r=0;r<e.length;r++){var i=e.charCodeAt(r);i<128?t[n++]=i:i<2048?(t[n++]=i>>6|192,t[n++]=63&i|128):55296===(64512&i)&&r+1<e.length&&56320===(64512&e.charCodeAt(r+1))?(i=65536+((1023&i)<<10)+(1023&e.charCodeAt(++r)),t[n++]=i>>18|240,t[n++]=i>>12&63|128,t[n++]=i>>6&63|128,t[n++]=63&i|128):(t[n++]=i>>12|224,t[n++]=i>>6&63|128,t[n++]=63&i|128)}return t},o=function(e){var t=[],n=0,r=0;while(n<e.length){var i=e[n++];if(i<128)t[r++]=String.fromCharCode(i);else if(i>191&&i<224){var o=e[n++];t[r++]=String.fromCharCode((31&i)<<6|63&o)}else if(i>239&&i<365){o=e[n++];var s=e[n++],a=e[n++],u=((7&i)<<18|(63&o)<<12|(63&s)<<6|63&a)-65536;t[r++]=String.fromCharCode(55296+(u>>10)),t[r++]=String.fromCharCode(56320+(1023&u))}else{o=e[n++],s=e[n++];t[r++]=String.fromCharCode((15&i)<<12|(63&o)<<6|63&s)}}return t.join("")};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function s(e){return a(void 0,e)}function a(e,t){if(!(t instanceof Object))return t;switch(t.constructor){case Date:var n=t;return new Date(n.getTime());case Object:void 0===e&&(e={});break;case Array:e=[];break;default:return t}for(var r in t)t.hasOwnProperty(r)&&u(r)&&(e[r]=a(e[r],t[r]));return e}function u(e){return"__proto__"!==e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var c=function(){function e(){var e=this;this.reject=function(){},this.resolve=function(){},this.promise=new Promise((function(t,n){e.resolve=t,e.reject=n}))}return e.prototype.wrapCallback=function(e){var t=this;return function(n,r){n?t.reject(n):t.resolve(r),"function"===typeof e&&(t.promise.catch((function(){})),1===e.length?e(n):e(n,r))}},e}();
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function l(){try{return"[object process]"===Object.prototype.toString.call(e.process)}catch(t){return!1}}function h(){return"object"===typeof self&&self.self===self}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var f="FirebaseError",p=function(e){function t(n,r,i){var o=e.call(this,r)||this;return o.code=n,o.customData=i,o.name=f,Object.setPrototypeOf(o,t.prototype),Error.captureStackTrace&&Error.captureStackTrace(o,d.prototype.create),o}return Object(r["c"])(t,e),t}(Error),d=function(){function e(e,t,n){this.service=e,this.serviceName=t,this.errors=n}return e.prototype.create=function(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];var r=t[0]||{},i=this.service+"/"+e,o=this.errors[e],s=o?v(o,r):"Error",a=this.serviceName+": "+s+" ("+i+").",u=new p(i,a,r);return u},e}();function v(e,t){return e.replace(_,(function(e,n){var r=t[n];return null!=r?String(r):"<"+n+"?>"}))}var _=/\{\$([^}]+)}/g;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function g(e,t){return Object.prototype.hasOwnProperty.call(e,t)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
(function(){function e(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=64,this.pad_[0]=128;for(var e=1;e<this.blockSize;++e)this.pad_[e]=0;this.reset()}e.prototype.reset=function(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0},e.prototype.compress_=function(e,t){t||(t=0);var n=this.W_;if("string"===typeof e)for(var r=0;r<16;r++)n[r]=e.charCodeAt(t)<<24|e.charCodeAt(t+1)<<16|e.charCodeAt(t+2)<<8|e.charCodeAt(t+3),t+=4;else for(r=0;r<16;r++)n[r]=e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3],t+=4;for(r=16;r<80;r++){var i=n[r-3]^n[r-8]^n[r-14]^n[r-16];n[r]=4294967295&(i<<1|i>>>31)}var o,s,a=this.chain_[0],u=this.chain_[1],c=this.chain_[2],l=this.chain_[3],h=this.chain_[4];for(r=0;r<80;r++){r<40?r<20?(o=l^u&(c^l),s=1518500249):(o=u^c^l,s=1859775393):r<60?(o=u&c|l&(u|c),s=2400959708):(o=u^c^l,s=3395469782);i=(a<<5|a>>>27)+o+h+s+n[r]&4294967295;h=l,l=c,c=4294967295&(u<<30|u>>>2),u=a,a=i}this.chain_[0]=this.chain_[0]+a&4294967295,this.chain_[1]=this.chain_[1]+u&4294967295,this.chain_[2]=this.chain_[2]+c&4294967295,this.chain_[3]=this.chain_[3]+l&4294967295,this.chain_[4]=this.chain_[4]+h&4294967295},e.prototype.update=function(e,t){if(null!=e){void 0===t&&(t=e.length);var n=t-this.blockSize,r=0,i=this.buf_,o=this.inbuf_;while(r<t){if(0===o)while(r<=n)this.compress_(e,r),r+=this.blockSize;if("string"===typeof e){while(r<t)if(i[o]=e.charCodeAt(r),++o,++r,o===this.blockSize){this.compress_(i),o=0;break}}else while(r<t)if(i[o]=e[r],++o,++r,o===this.blockSize){this.compress_(i),o=0;break}}this.inbuf_=o,this.total_+=t}},e.prototype.digest=function(){var e=[],t=8*this.total_;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(var n=this.blockSize-1;n>=56;n--)this.buf_[n]=255&t,t/=256;this.compress_(this.buf_);var r=0;for(n=0;n<5;n++)for(var i=24;i>=0;i-=8)e[r]=this.chain_[n]>>i&255,++r;return e}})();function b(e,t){var n=new m(e,t);return n.subscribe.bind(n)}var m=function(){function e(e,t){var n=this;this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then((function(){e(n)})).catch((function(e){n.error(e)}))}return e.prototype.next=function(e){this.forEachObserver((function(t){t.next(e)}))},e.prototype.error=function(e){this.forEachObserver((function(t){t.error(e)})),this.close(e)},e.prototype.complete=function(){this.forEachObserver((function(e){e.complete()})),this.close()},e.prototype.subscribe=function(e,t,n){var r,i=this;if(void 0===e&&void 0===t&&void 0===n)throw new Error("Missing Observer.");r=y(e,["next","error","complete"])?e:{next:e,error:t,complete:n},void 0===r.next&&(r.next=w),void 0===r.error&&(r.error=w),void 0===r.complete&&(r.complete=w);var o=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then((function(){try{i.finalError?r.error(i.finalError):r.complete()}catch(e){}})),this.observers.push(r),o},e.prototype.unsubscribeOne=function(e){void 0!==this.observers&&void 0!==this.observers[e]&&(delete this.observers[e],this.observerCount-=1,0===this.observerCount&&void 0!==this.onNoObservers&&this.onNoObservers(this))},e.prototype.forEachObserver=function(e){if(!this.finalized)for(var t=0;t<this.observers.length;t++)this.sendOne(t,e)},e.prototype.sendOne=function(e,t){var n=this;this.task.then((function(){if(void 0!==n.observers&&void 0!==n.observers[e])try{t(n.observers[e])}catch(r){"undefined"!==typeof console&&console.error&&console.error(r)}}))},e.prototype.close=function(e){var t=this;this.finalized||(this.finalized=!0,void 0!==e&&(this.finalError=e),this.task.then((function(){t.observers=void 0,t.onNoObservers=void 0})))},e}();function y(e,t){if("object"!==typeof e||null===e)return!1;for(var n=0,r=t;n<r.length;n++){var i=r[n];if(i in e&&"function"===typeof e[i])return!0}return!1}function w(){}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function R(e){return e&&e._delegate?e._delegate:e}}).call(this,n("c8ba"))},abfd:function(e,t,n){"use strict";
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
function r(){for(var e=0,t=0,n=arguments.length;t<n;t++)e+=arguments[t].length;var r=Array(e),i=0;for(t=0;t<n;t++)for(var o=arguments[t],s=0,a=o.length;s<a;s++,i++)r[i]=o[s];return r}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var i;n.d(t,"a",(function(){return h})),n.d(t,"b",(function(){return f})),n.d(t,"c",(function(){return p}));var o,s=[];(function(e){e[e["DEBUG"]=0]="DEBUG",e[e["VERBOSE"]=1]="VERBOSE",e[e["INFO"]=2]="INFO",e[e["WARN"]=3]="WARN",e[e["ERROR"]=4]="ERROR",e[e["SILENT"]=5]="SILENT"})(o||(o={}));var a={debug:o.DEBUG,verbose:o.VERBOSE,info:o.INFO,warn:o.WARN,error:o.ERROR,silent:o.SILENT},u=o.INFO,c=(i={},i[o.DEBUG]="log",i[o.VERBOSE]="log",i[o.INFO]="info",i[o.WARN]="warn",i[o.ERROR]="error",i),l=function(e,t){for(var n=[],i=2;i<arguments.length;i++)n[i-2]=arguments[i];if(!(t<e.logLevel)){var o=(new Date).toISOString(),s=c[t];if(!s)throw new Error("Attempted to log a message with an invalid logType (value: "+t+")");console[s].apply(console,r(["["+o+"]  "+e.name+":"],n))}},h=function(){function e(e){this.name=e,this._logLevel=u,this._logHandler=l,this._userLogHandler=null,s.push(this)}return Object.defineProperty(e.prototype,"logLevel",{get:function(){return this._logLevel},set:function(e){if(!(e in o))throw new TypeError('Invalid value "'+e+'" assigned to `logLevel`');this._logLevel=e},enumerable:!1,configurable:!0}),e.prototype.setLogLevel=function(e){this._logLevel="string"===typeof e?a[e]:e},Object.defineProperty(e.prototype,"logHandler",{get:function(){return this._logHandler},set:function(e){if("function"!==typeof e)throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"userLogHandler",{get:function(){return this._userLogHandler},set:function(e){this._userLogHandler=e},enumerable:!1,configurable:!0}),e.prototype.debug=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,o.DEBUG],e)),this._logHandler.apply(this,r([this,o.DEBUG],e))},e.prototype.log=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,o.VERBOSE],e)),this._logHandler.apply(this,r([this,o.VERBOSE],e))},e.prototype.info=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,o.INFO],e)),this._logHandler.apply(this,r([this,o.INFO],e))},e.prototype.warn=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,o.WARN],e)),this._logHandler.apply(this,r([this,o.WARN],e))},e.prototype.error=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,r([this,o.ERROR],e)),this._logHandler.apply(this,r([this,o.ERROR],e))},e}();function f(e){s.forEach((function(t){t.setLogLevel(e)}))}function p(e,t){for(var n=function(n){var r=null;t&&t.level&&(r=a[t.level]),n.userLogHandler=null===e?null:function(t,n){for(var i=[],s=2;s<arguments.length;s++)i[s-2]=arguments[s];var a=i.map((function(e){if(null==e)return null;if("string"===typeof e)return e;if("number"===typeof e||"boolean"===typeof e)return e.toString();if(e instanceof Error)return e.message;try{return JSON.stringify(e)}catch(t){return null}})).filter((function(e){return e})).join(" ");n>=(null!==r&&void 0!==r?r:t.logLevel)&&e({level:o[n].toLowerCase(),message:a,args:i,type:t.name})}},r=0,i=s;r<i.length;r++){var u=i[r];n(u)}}},ffa6:function(e,t,n){"use strict";n.d(t,"a",(function(){return o})),n.d(t,"b",(function(){return l}));var r=n("9ab4"),i=n("a8e9"),o=function(){function e(e,t,n){this.name=e,this.instanceFactory=t,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}return e.prototype.setInstantiationMode=function(e){return this.instantiationMode=e,this},e.prototype.setMultipleInstances=function(e){return this.multipleInstances=e,this},e.prototype.setServiceProps=function(e){return this.serviceProps=e,this},e.prototype.setInstanceCreatedCallback=function(e){return this.onInstanceCreated=e,this},e}(),s="[DEFAULT]",a=function(){function e(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.onInitCallbacks=new Map}return e.prototype.get=function(e){var t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){var n=new i["a"];if(this.instancesDeferred.set(t,n),this.isInitialized(t)||this.shouldAutoInitialize())try{var r=this.getOrInitializeService({instanceIdentifier:t});r&&n.resolve(r)}catch(o){}}return this.instancesDeferred.get(t).promise},e.prototype.getImmediate=function(e){var t,n=this.normalizeInstanceIdentifier(null===e||void 0===e?void 0:e.identifier),r=null!==(t=null===e||void 0===e?void 0:e.optional)&&void 0!==t&&t;if(!this.isInitialized(n)&&!this.shouldAutoInitialize()){if(r)return null;throw Error("Service "+this.name+" is not available")}try{return this.getOrInitializeService({instanceIdentifier:n})}catch(i){if(r)return null;throw i}},e.prototype.getComponent=function(){return this.component},e.prototype.setComponent=function(e){var t,n;if(e.name!==this.name)throw Error("Mismatching Component "+e.name+" for Provider "+this.name+".");if(this.component)throw Error("Component for "+this.name+" has already been provided");if(this.component=e,this.shouldAutoInitialize()){if(c(e))try{this.getOrInitializeService({instanceIdentifier:s})}catch(p){}try{for(var i=Object(r["g"])(this.instancesDeferred.entries()),o=i.next();!o.done;o=i.next()){var a=Object(r["e"])(o.value,2),u=a[0],l=a[1],h=this.normalizeInstanceIdentifier(u);try{var f=this.getOrInitializeService({instanceIdentifier:h});l.resolve(f)}catch(p){}}}catch(d){t={error:d}}finally{try{o&&!o.done&&(n=i.return)&&n.call(i)}finally{if(t)throw t.error}}}},e.prototype.clearInstance=function(e){void 0===e&&(e=s),this.instancesDeferred.delete(e),this.instances.delete(e)},e.prototype.delete=function(){return Object(r["b"])(this,void 0,void 0,(function(){var e;return Object(r["d"])(this,(function(t){switch(t.label){case 0:return e=Array.from(this.instances.values()),[4,Promise.all(Object(r["f"])(Object(r["f"])([],Object(r["e"])(e.filter((function(e){return"INTERNAL"in e})).map((function(e){return e.INTERNAL.delete()})))),Object(r["e"])(e.filter((function(e){return"_delete"in e})).map((function(e){return e._delete()})))))];case 1:return t.sent(),[2]}}))}))},e.prototype.isComponentSet=function(){return null!=this.component},e.prototype.isInitialized=function(e){return void 0===e&&(e=s),this.instances.has(e)},e.prototype.initialize=function(e){var t,n;void 0===e&&(e={});var i=e.options,o=void 0===i?{}:i,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(this.name+"("+s+") has already been initialized");if(!this.isComponentSet())throw Error("Component "+this.name+" has not been registered yet");var a=this.getOrInitializeService({instanceIdentifier:s,options:o});try{for(var u=Object(r["g"])(this.instancesDeferred.entries()),c=u.next();!c.done;c=u.next()){var l=Object(r["e"])(c.value,2),h=l[0],f=l[1],p=this.normalizeInstanceIdentifier(h);s===p&&f.resolve(a)}}catch(d){t={error:d}}finally{try{c&&!c.done&&(n=u.return)&&n.call(u)}finally{if(t)throw t.error}}return this.invokeOnInitCallbacks(a,s),a},e.prototype.onInit=function(e,t){var n,r=this.normalizeInstanceIdentifier(t),i=null!==(n=this.onInitCallbacks.get(r))&&void 0!==n?n:new Set;i.add(e),this.onInitCallbacks.set(r,i);var o=this.instances.get(r);return o&&e(o,r),function(){i.delete(e)}},e.prototype.invokeOnInitCallbacks=function(e,t){var n,i,o=this.onInitCallbacks.get(t);if(o)try{for(var s=Object(r["g"])(o),a=s.next();!a.done;a=s.next()){var u=a.value;try{u(e,t)}catch(c){}}}catch(l){n={error:l}}finally{try{a&&!a.done&&(i=s.return)&&i.call(s)}finally{if(n)throw n.error}}},e.prototype.getOrInitializeService=function(e){var t=e.instanceIdentifier,n=e.options,r=void 0===n?{}:n,i=this.instances.get(t);if(!i&&this.component&&(i=this.component.instanceFactory(this.container,{instanceIdentifier:u(t),options:r}),this.instances.set(t,i),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,i)}catch(o){}return i||null},e.prototype.normalizeInstanceIdentifier=function(e){return void 0===e&&(e=s),this.component?this.component.multipleInstances?e:s:e},e.prototype.shouldAutoInitialize=function(){return!!this.component&&"EXPLICIT"!==this.component.instantiationMode},e}();function u(e){return e===s?void 0:e}function c(e){return"EAGER"===e.instantiationMode}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var l=function(){function e(e){this.name=e,this.providers=new Map}return e.prototype.addComponent=function(e){var t=this.getProvider(e.name);if(t.isComponentSet())throw new Error("Component "+e.name+" has already been registered with "+this.name);t.setComponent(e)},e.prototype.addOrOverwriteComponent=function(e){var t=this.getProvider(e.name);t.isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)},e.prototype.getProvider=function(e){if(this.providers.has(e))return this.providers.get(e);var t=new a(e,this);return this.providers.set(e,t),t},e.prototype.getProviders=function(){return Array.from(this.providers.values())},e}()}}]);